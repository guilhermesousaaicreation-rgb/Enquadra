package pt.enquadra

import android.graphics.*
import java.util.Calendar
import java.util.Date
import kotlin.math.*
import kotlin.random.Random

/** Um "look" é uma predefinição: ajustes + lift/gamma/gain por canal (cor de filme). */
class Look(
    val name: String,
    val a: Map<String, Int> = mapOf(),
    val lift: FloatArray = floatArrayOf(0f, 0f, 0f),
    val gamma: FloatArray = floatArrayOf(1f, 1f, 1f),
    val gain: FloatArray = floatArrayOf(1f, 1f, 1f),
    val mono: Boolean = false
)

/** a = ajustes do utilizador (por cima do look); amt = intensidade do look (0-100). */
class P(
    val a: HashMap<String, Int> = HashMap(),
    var look: Look? = null,
    var amt: Int = 100,
    var frame: String = "plain",
    var date: Boolean = false
) {
    fun u(k: String): Int = a[k] ?: 0
    fun g(k: String): Float = (a[k] ?: 0) + (look?.a?.get(k) ?: 0) * amt / 100f
    fun copy(): P = P(HashMap(a), look, amt, frame, date)
}

class Cap(val zoom: Float = 1f, val iso: Int = 0, val et: Long = 0L, val date: Date = Date(), val model: String = "")

val LOOKS = listOf(
    Look("Original"),
    Look("Mel", mapOf("temp" to 8, "contrast" to 10, "highlights" to -12, "shadows" to 10, "fade" to 8, "sat" to -6, "vibrance" to 10, "grain" to 14, "halation" to 16),
        lift = floatArrayOf(.010f, .005f, 0f), gain = floatArrayOf(1.04f, 1f, .95f)),
    Look("Sienna", mapOf("temp" to 18, "tint" to 4, "contrast" to 14, "highlights" to -10, "fade" to 14, "sat" to -10, "grain" to 22, "halation" to 28, "vig" to 18, "leak" to 8),
        lift = floatArrayOf(.015f, .008f, 0f), gain = floatArrayOf(1.06f, 1f, .90f)),
    Look("Dusk", mapOf("exposure" to -6, "contrast" to 20, "sat" to -8, "fade" to 6, "grain" to 18, "halation" to 20, "vig" to 24),
        lift = floatArrayOf(.020f, 0f, .030f), gain = floatArrayOf(1.03f, .98f, .96f)),
    Look("Harbor", mapOf("temp" to -10, "contrast" to 12, "sat" to -14, "fade" to 10, "grain" to 16, "clarity" to 6),
        lift = floatArrayOf(-.005f, .012f, .020f), gain = floatArrayOf(.97f, 1f, 1.04f)),
    Look("Arquivo", mapOf("temp" to 6, "contrast" to -6, "sat" to -20, "fade" to 22, "grain" to 28, "dust" to 25, "vig" to 20),
        lift = floatArrayOf(.030f, .025f, .020f)),
    Look("Relic", mapOf("temp" to 24, "tint" to 4, "sat" to -45, "fade" to 24, "grain" to 30, "dust" to 22, "vig" to 20),
        lift = floatArrayOf(.030f, .020f, 0f), gain = floatArrayOf(1.05f, .98f, .85f)),
    Look("Cobalto", mapOf("temp" to -18, "contrast" to 16, "vibrance" to 12, "grain" to 12, "glow" to 14, "clarity" to 10),
        lift = floatArrayOf(-.010f, 0f, .020f), gain = floatArrayOf(.96f, 1f, 1.06f)),
    Look("Verde", mapOf("tint" to -10, "contrast" to 10, "fade" to 6, "sat" to 8, "grain" to 20),
        lift = floatArrayOf(-.005f, .012f, 0f), gain = floatArrayOf(.98f, 1.03f, .98f)),
    Look("Ouro", mapOf("temp" to 22, "contrast" to 12, "sat" to 10, "vibrance" to 10, "halation" to 16, "vig" to 16, "grain" to 12),
        gain = floatArrayOf(1.06f, 1.01f, .90f)),
    Look("Cine", mapOf("contrast" to 16, "sat" to 6, "highlights" to -8, "grain" to 12, "vig" to 14),
        lift = floatArrayOf(-.010f, .010f, .030f), gain = floatArrayOf(1.06f, 1f, .92f)),
    Look("Limpo", mapOf("contrast" to 6, "vibrance" to 8, "clarity" to 12, "sharpen" to 20)),
    Look("P&B", mapOf("contrast" to 22, "grain" to 30, "vig" to 16, "clarity" to 10), mono = true),
    Look("Noir", mapOf("contrast" to 40, "blacks" to -20, "grain" to 38, "vig" to 30, "clarity" to 14), mono = true)
)
val FR = listOf("plain" to "Simples", "white" to "Branca", "paper" to "Papel", "black" to "Preta", "negative" to "Negativo", "specs" to "Specs")

object Film {
    private val s2l = FloatArray(256) { i ->
        val v = i / 255f
        if (v <= .04045f) v / 12.92f else ((v + .055f) / 1.055f).pow(2.4f)
    }
    private val l2g = FloatArray(4097) { i ->
        val v = i / 4096f
        if (v <= .0031308f) v * 12.92f else 1.055f * v.pow(1f / 2.4f) - .055f
    }

    fun scaled(b: Bitmap, L: Int): Bitmap {
        var t = b
        while (max(t.width, t.height) > L * 2) t = Bitmap.createScaledBitmap(t, t.width / 2, t.height / 2, true)
        val k = L.toFloat() / max(t.width, t.height)
        if (k >= 1f) return t
        return Bitmap.createScaledBitmap(t, max(1, (t.width * k).roundToInt()), max(1, (t.height * k).roundToInt()), true)
    }

    private fun lm(c: Int): Float = (.2126f * ((c shr 16) and 255) + .7152f * ((c shr 8) and 255) + .0722f * (c and 255)) / 255f

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun curve(x: Float, c: Float): Float =
        if (c > 0f) { val t = x.coerceIn(0f, 1f); x + (t * t * (3f - 2f * t) - x) * c * 1.4f }
        else .5f + (x - .5f) * (1f + c * .8f)

    private fun hsh(x: Int, y: Int, s: Int): Float {
        var q = x * 374761393 + y * 668265263 + s * 1274126177
        q = (q xor (q ushr 13)) * 1274126177
        q = q xor (q ushr 16)
        return (q and 0xffff) / 65535f
    }

    private fun blurBox(a: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val t = FloatArray(a.size)
        val o = FloatArray(a.size)
        val d = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val row = y * w
            var s = 0f
            for (i in -r..r) s += a[row + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                t[row + x] = s / d
                s += a[row + (x + r + 1).coerceAtMost(w - 1)] - a[row + (x - r).coerceAtLeast(0)]
            }
        }
        for (x in 0 until w) {
            var s = 0f
            for (i in -r..r) s += t[i.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                o[y * w + x] = s / d
                s += t[(y + r + 1).coerceAtMost(h - 1) * w + x] - t[(y - r).coerceAtLeast(0) * w + x]
            }
        }
        return o
    }

    private fun samp(m: FloatArray, lw: Int, lh: Int, w: Int, h: Int, x: Int, y: Int): Float {
        val fx = (x + .5f) * lw / w - .5f
        val fy = (y + .5f) * lh / h - .5f
        val x0 = floor(fx).toInt()
        val y0 = floor(fy).toInt()
        val tx = fx - x0
        val ty = fy - y0
        val xa = x0.coerceIn(0, lw - 1)
        val xb = (x0 + 1).coerceIn(0, lw - 1)
        val ya = y0.coerceIn(0, lh - 1)
        val yb = (y0 + 1).coerceIn(0, lh - 1)
        val a = m[ya * lw + xa] * (1 - tx) + m[ya * lw + xb] * tx
        val c = m[yb * lw + xa] * (1 - tx) + m[yb * lw + xb] * tx
        return a * (1 - ty) + c * ty
    }

    /** Revelação: luz linear, balanço de brancos, curvas, clareza, nitidez, cor de filme, halation, grão. */
    fun render(b: Bitmap, p: P, seed: Int): Bitmap {
        val w = b.width
        val h = b.height
        val src = IntArray(w * h)
        b.getPixels(src, 0, w, 0, 0, w, h)
        val res = IntArray(w * h)
        val look = p.look
        val amtF = if (look == null) 0f else p.amt / 100f
        val ex = 2f.pow(p.g("exposure") / 40f)
        val con = p.g("contrast") / 100f
        val hil = p.g("highlights") / 100f
        val sha = p.g("shadows") / 100f
        val whi = p.g("whites") / 100f
        val bla = p.g("blacks") / 100f
        val tmp = p.g("temp") / 100f
        val tnt = p.g("tint") / 100f
        val vib = p.g("vibrance") / 100f
        val sat = p.g("sat") / 100f
        val cla = p.g("clarity") / 100f
        val shp = p.g("sharpen") / 100f
        val fad = p.g("fade") / 100f
        val grn = p.g("grain") / 100f
        val hal = p.g("halation") / 100f
        val glo = p.g("glow") / 100f
        val lek = p.g("leak") / 100f
        val vig = p.g("vig") / 100f
        val mono = if (look != null && look.mono) amtF else 0f
        val useLut = look != null && amtF > 0f
        val lut = Array(3) { FloatArray(4096) }
        if (useLut && look != null) {
            for (c in 0..2) {
                val lf = look.lift[c] * amtF
                val gn = 1f + (look.gain[c] - 1f) * amtF
                val inv = 1f / (1f + (look.gamma[c] - 1f) * amtF)
                for (i in 0 until 4096) {
                    val x = i / 4095f
                    lut[c][i] = ((x * (1f - lf) + lf) * gn).coerceIn(0f, 1f).pow(inv)
                }
            }
        }
        // mapas de baixa resolução: clareza, halation, brilho
        val lw = max(2, w / 8)
        val lh = max(2, h / 8)
        var mapC: FloatArray? = null
        var mapH: FloatArray? = null
        var mapG: FloatArray? = null
        if (cla != 0f || hal > 0f || glo > 0f) {
            val low = FloatArray(lw * lh)
            val cnt = IntArray(lw * lh)
            for (y in 0 until h) {
                val ly = min(lh - 1, y * lh / h)
                val row = y * w
                for (x in 0 until w) {
                    val li = ly * lw + min(lw - 1, x * lw / w)
                    low[li] += lm(src[row + x])
                    cnt[li]++
                }
            }
            for (i in low.indices) if (cnt[i] > 0) low[i] = low[i] / cnt[i]
            if (cla != 0f) { val r1 = max(2, lw / 12); mapC = blurBox(blurBox(low, lw, lh, r1), lw, lh, r1) }
            if (hal > 0f) {
                val hm = FloatArray(low.size) { max(0f, low[it] - .70f) / .30f }
                val r2 = max(2, lw / 30)
                mapH = blurBox(blurBox(hm, lw, lh, r2), lw, lh, r2)
            }
            if (glo > 0f) {
                val gm = FloatArray(low.size) { max(0f, low[it] - .45f) / .55f }
                val r3 = max(2, lw / 16)
                mapG = blurBox(blurBox(gm, lw, lh, r3), lw, lh, r3)
            }
        }
        val hasTone = sha != 0f || hil != 0f || whi != 0f || bla != 0f
        val cx = w / 2f
        val cy = h / 2f
        val gxl = if ((seed and 1) == 1) 1f else 0f
        val gyl = ((seed shr 2) and 3) / 4f + .15f
        val cell = max(1.5f, w / 420f)
        for (y in 0 until h) {
            val row = y * w
            val yu = if (y > 0) row - w else row
            val yd = if (y < h - 1) row + w else row
            for (x in 0 until w) {
                val i = row + x
                val c = src[i]
                var add = 0f
                if (shp > 0f) {
                    val xl = if (x > 0) i - 1 else i
                    val xr = if (x < w - 1) i + 1 else i
                    val ys = (lm(src[xl]) + lm(src[xr]) + lm(src[yu + x]) + lm(src[yd + x])) * .25f
                    add += (lm(c) - ys) * shp * 1.3f
                }
                var r = s2l[(c shr 16) and 255]
                var g = s2l[(c shr 8) and 255]
                var bl = s2l[c and 255]
                if (tmp != 0f || tnt != 0f) {
                    r *= 1f + tmp * .30f + tnt * .06f
                    bl *= 1f - tmp * .30f + tnt * .06f
                    g *= 1f - tnt * .18f
                }
                r *= ex; g *= ex; bl *= ex
                r = l2g[(r * 4096f).toInt().coerceIn(0, 4096)]
                g = l2g[(g * 4096f).toInt().coerceIn(0, 4096)]
                bl = l2g[(bl * 4096f).toInt().coerceIn(0, 4096)]
                var l = .2126f * r + .7152f * g + .0722f * bl
                val bm = mapC
                if (bm != null) {
                    val mid = max(0f, 1f - abs(l - .5f) * 1.7f)
                    add += (l - samp(bm, lw, lh, w, h, x, y)) * cla * 1.2f * mid
                }
                if (add != 0f) { r += add; g += add; bl += add; l += add }
                if (hasTone) {
                    val lc = l.coerceIn(0f, 1f)
                    val a = sha * .30f * (1f - lc) * (1f - lc) + hil * .30f * lc * lc +
                        whi * .16f * smooth(.55f, 1f, lc) + bla * .16f * (1f - smooth(0f, .45f, lc))
                    r += a; g += a; bl += a
                }
                if (con != 0f) { r = curve(r, con); g = curve(g, con); bl = curve(bl, con) }
                if (fad > 0f) {
                    val f = fad * .17f
                    r = f + r * (1f - f); g = f + g * (1f - f); bl = f + bl * (1f - f)
                }
                if (useLut) {
                    r = lut[0][(r.coerceIn(0f, 1f) * 4095f).toInt()]
                    g = lut[1][(g.coerceIn(0f, 1f) * 4095f).toInt()]
                    bl = lut[2][(bl.coerceIn(0f, 1f) * 4095f).toInt()]
                }
                if (sat != 0f || vib != 0f) {
                    val mx = max(r, max(g, bl))
                    val mn = min(r, min(g, bl))
                    val ch = if (mx > .0001f) (mx - mn) / mx else 0f
                    val f = 1f + sat + vib * (1f - ch) * .9f
                    val ll = .2126f * r + .7152f * g + .0722f * bl
                    r = ll + (r - ll) * f; g = ll + (g - ll) * f; bl = ll + (bl - ll) * f
                }
                if (mono > 0f) {
                    val gy = .40f * r + .45f * g + .15f * bl
                    r += (gy - r) * mono; g += (gy - g) * mono; bl += (gy - bl) * mono
                }
                val mh = mapH
                if (mh != null) {
                    val hv = samp(mh, lw, lh, w, h, x, y) * hal * .8f
                    r += hv; g += hv * .38f; bl += hv * .12f
                }
                val mg = mapG
                if (mg != null) {
                    val gv = samp(mg, lw, lh, w, h, x, y) * glo * .35f
                    r += gv; g += gv; bl += gv
                }
                if (lek > 0f) {
                    val dx = x.toFloat() / w - gxl
                    val dy = y.toFloat() / h - gyl
                    val q = 1f / (1f + 9f * (dx * dx * 1.6f + dy * dy))
                    val a = lek * .9f * q * q
                    r = 1f - (1f - r) * (1f - a)
                    g = 1f - (1f - g) * (1f - a * .42f)
                    bl = 1f - (1f - bl) * (1f - a * .14f)
                }
                if (vig > 0f) {
                    val dx = (x - cx) / cx
                    val dy = (y - cy) / cy
                    val v = 1f - vig * .8f * smooth(.35f, 1f, sqrt(dx * dx + dy * dy) / 1.414f)
                    r *= v; g *= v; bl *= v
                }
                if (grn > 0f) {
                    val gx = x / cell
                    val gy = y / cell
                    val ix = gx.toInt()
                    val iy = gy.toInt()
                    val fx = gx - ix
                    val fy = gy - iy
                    val coarse = (hsh(ix, iy, seed) * (1 - fx) + hsh(ix + 1, iy, seed) * fx) * (1 - fy) +
                        (hsh(ix, iy + 1, seed) * (1 - fx) + hsh(ix + 1, iy + 1, seed) * fx) * fy
                    val nn = (hsh(x, y, seed + 7) * .5f + coarse * .5f - .5f) * 2f
                    val lu = .2126f * r + .7152f * g + .0722f * bl
                    val mid = 1f - (abs(lu - .5f) * 1.6f).coerceIn(0f, 1f)
                    val amp = grn * .14f * (.35f + .65f * mid)
                    r += nn * amp; g += nn * amp; bl += nn * amp
                }
                val ri = (r * 255f + .5f).toInt().coerceIn(0, 255)
                val gi = (g * 255f + .5f).toInt().coerceIn(0, 255)
                val bi = (bl * 255f + .5f).toInt().coerceIn(0, 255)
                res[i] = (0xff shl 24) or (ri shl 16) or (gi shl 8) or bi
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(res, 0, w, 0, 0, w, h)
        val du = p.g("dust").toInt()
        if (du > 0) {
            val cv = Canvas(out)
            val rd = Random(seed)
            val n = (du.toLong() * w * h / 200000L).toInt()
            val pt = Paint(Paint.ANTI_ALIAS_FLAG)
            for (i in 0 until n) {
                pt.color = if (rd.nextFloat() > .3f) Color.argb(140, 255, 255, 255) else Color.argb(100, 0, 0, 0)
                cv.drawCircle(rd.nextFloat() * w, rd.nextFloat() * h, rd.nextFloat() * 1.4f * (w / 700f) + .3f, pt)
            }
            pt.color = Color.argb(65, 255, 255, 255)
            pt.strokeWidth = max(.8f, w / 900f)
            for (i in 0 until n / 12) {
                val x = rd.nextFloat() * w
                val y = rd.nextFloat() * h
                cv.drawLine(x, y, x + (rd.nextFloat() - .5f) * w * .02f, y + rd.nextFloat() * h * .08f, pt)
            }
        }
        return out
    }

    fun compose(c: Bitmap, p: P, cap: Cap): Bitmap {
        val w = c.width
        val h = c.height
        val m = min(w, h).toFloat()
        val cal = Calendar.getInstance()
        cal.time = cap.date
        val yy = cal.get(Calendar.YEAR)
        val mo = cal.get(Calendar.MONTH) + 1
        val dd = cal.get(Calendar.DAY_OF_MONTH)
        fun p2(n: Int) = n.toString().padStart(2, '0')
        if (p.date) {
            val cv = Canvas(c)
            val pt = Paint(Paint.ANTI_ALIAS_FLAG)
            pt.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            pt.textSize = m * .04f
            pt.textAlign = Paint.Align.RIGHT
            pt.color = Color.parseColor("#FF8A1F")
            pt.setShadowLayer(m * .012f, 0f, 0f, Color.parseColor("#FF6A00"))
            cv.drawText("’" + (yy % 100).toString().padStart(2, '0') + " " + p2(mo) + " " + p2(dd), w - m * .04f, h - m * .04f, pt)
        }
        val cfg: FloatArray
        val bg: Int
        when (p.frame) {
            "white" -> { cfg = floatArrayOf(.05f, .05f, .05f, .05f); bg = Color.parseColor("#FBFAF6") }
            "paper" -> { cfg = floatArrayOf(.06f, .06f, .06f, .06f); bg = Color.parseColor("#EDE4CF") }
            "black" -> { cfg = floatArrayOf(.05f, .05f, .05f, .05f); bg = Color.parseColor("#0A0A0A") }
            "negative" -> { cfg = floatArrayOf(.13f, .05f, .13f, .05f); bg = Color.parseColor("#14110E") }
            "specs" -> { cfg = floatArrayOf(.05f, .05f, .16f, .05f); bg = Color.parseColor("#FBFAF6") }
            else -> return c
        }
        val t = (cfg[0] * m).roundToInt()
        val l = (cfg[1] * m).roundToInt()
        val b = (cfg[2] * m).roundToInt()
        val r = (cfg[3] * m).roundToInt()
        val ow = w + l + r
        val oh = h + t + b
        val o = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(o)
        cv.drawColor(bg)
        val pt = Paint(Paint.ANTI_ALIAS_FLAG)
        if (p.frame == "paper") {
            val rd = Random(7)
            pt.color = Color.argb(18, 120, 100, 60)
            for (i in 0 until 400) {
                val x = rd.nextFloat() * ow
                val y = rd.nextFloat() * oh
                cv.drawRect(x, y, x + 1f + rd.nextFloat() * 2f, y + 1f + rd.nextFloat() * 2f, pt)
            }
        }
        cv.drawBitmap(c, l.toFloat(), t.toFloat(), null)
        if (p.frame == "negative") {
            pt.color = Color.argb(217, 217, 210, 196)
            val hw = m * .035f
            val hh = m * .022f
            var x = hw
            while (x < ow - hw) {
                cv.drawRoundRect(RectF(x, t * .22f, x + hw, t * .22f + hh), 3f, 3f, pt)
                cv.drawRoundRect(RectF(x, oh - t * .22f - hh, x + hw, oh - t * .22f), 3f, 3f, pt)
                x += hw * 2
            }
            pt.color = Color.parseColor("#E89A2A")
            pt.typeface = Typeface.MONOSPACE
            pt.textSize = m * .03f
            pt.textAlign = Paint.Align.LEFT
            cv.drawText("▸ 14A", l.toFloat(), oh - t * .4f, pt)
        }
        if (p.frame == "specs") {
            val sh = if (cap.et > 0) "1/" + (1e9 / cap.et).roundToInt() else "AUTO"
            val iso = if (cap.iso > 0) cap.iso.toString() else "AUTO"
            pt.color = Color.parseColor("#2A2722")
            pt.typeface = Typeface.MONOSPACE
            pt.textSize = m * .030f
            pt.textAlign = Paint.Align.LEFT
            val y1 = h + t + b * .38f
            val y2 = h + t + b * .72f
            cv.drawText(String.format("%.1fx  ISO %s  %s", cap.zoom, iso, sh), l.toFloat(), y1, pt)
            if (cap.model.isNotEmpty()) cv.drawText("Shot on " + cap.model, l.toFloat(), y2, pt)
            pt.textAlign = Paint.Align.RIGHT
            cv.drawText(p2(dd) + "." + p2(mo) + "." + yy, (ow - r).toFloat(), y1, pt)
        }
        return o
    }
}
