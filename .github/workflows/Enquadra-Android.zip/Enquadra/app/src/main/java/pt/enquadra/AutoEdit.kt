package pt.enquadra

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** "Edição IA": analisa a imagem (histograma, cor, luz) e o tipo de cena (ML Kit) e propõe a melhor edição. */
object AutoEdit {
    class Stats(
        val p5: Float, val p50: Float, val p95: Float, val std: Float,
        val clip: Float, val crush: Float, val sat: Float, val cast: Float, val tintCast: Float
    )

    class Result(val params: HashMap<String, Int>, val look: String, val text: String)

    fun stats(b: Bitmap): Stats {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val hist = IntArray(256)
        var sum = 0.0
        var sum2 = 0.0
        var sr = 0.0
        var sg = 0.0
        var sb = 0.0
        var nn = 0
        var satSum = 0.0
        for (c in px) {
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val bl = c and 255
            val l = (.2126f * r + .7152f * g + .0722f * bl) / 255f
            hist[(l * 255f).toInt().coerceIn(0, 255)]++
            sum += l
            sum2 += l * l
            val mx = max(r, max(g, bl))
            val mn = min(r, min(g, bl))
            val s = if (mx > 0) (mx - mn) / mx.toFloat() else 0f
            satSum += s
            if (l >= .15f && l <= .85f && s < .4f) { sr += r; sg += g; sb += bl; nn++ }
        }
        val n = px.size
        fun pct(q: Float): Float {
            var acc = 0
            val t = (n * q).toInt()
            for (i in 0..255) { acc += hist[i]; if (acc >= t) return i / 255f }
            return 1f
        }
        val mean = sum / n
        val std = sqrt(max(0.0, sum2 / n - mean * mean)).toFloat()
        var clip = 0
        for (i in 248..255) clip += hist[i]
        var crush = 0
        for (i in 0..10) crush += hist[i]
        val ok = nn > n / 50
        val cast = if (ok) ((sr - sb) / (sr + sb + 1e-3)).toFloat() else 0f
        val tintC = if (ok) ((sg - (sr + sb) / 2) / (sg + (sr + sb) / 2 + 1e-3)).toFloat() else 0f
        return Stats(pct(.05f), pct(.5f), pct(.95f), std, clip / n.toFloat(), crush / n.toFloat(), (satSum / n).toFloat(), cast, tintC)
    }

    fun build(s: Stats, labels: List<String>): Result {
        val lows = labels.map { it.lowercase() }
        fun has(vararg k: String) = lows.any { l -> k.any { l.contains(it) } }
        var scene = "geral"
        var look = "Limpo"
        var vib = 8
        var cla = 10
        var shp = 22
        var warm = false
        when {
            has("sunset", "sunrise", "dusk", "dawn") -> { scene = "pôr do sol"; look = "Ouro"; warm = true; vib = 10 }
            has("food", "dish", "cuisine", "meal", "dessert", "fruit", "vegetable") -> { scene = "comida"; look = "Mel"; vib = 16; cla = 14 }
            has("face", "smile", "skin", "person", "selfie", "forehead", "cheek") -> { scene = "retrato"; look = "Mel"; cla = -6; shp = 12; vib = 4 }
            has("flower", "plant", "tree", "grass", "leaf", "forest", "garden", "palm") -> { scene = "natureza"; look = "Verde"; vib = 16 }
            has("sea", "ocean", "beach", "water", "sky", "cloud", "mountain", "lake", "coast", "horizon") -> { scene = "paisagem"; look = "Cobalto"; cla = 16; vib = 14 }
            has("building", "architecture", "city", "skyscraper", "tower", "street", "bridge", "house", "urban") -> { scene = "arquitetura"; look = "Cine"; cla = 18 }
            s.p50 < .22f || has("night", "darkness") -> { scene = "noite"; look = "Dusk"; cla = 6 }
        }
        val ev = log2(0.46f.pow(2.2f) / s.p50.coerceAtLeast(.02f).pow(2.2f)) * .7f
        val exposure = (ev.coerceIn(-1f, 1f) * 40f).roundToInt()
        val highlights = if (s.clip > .01f) -min(45, (15f + s.clip * 500f).roundToInt()) else if (s.p95 > .93f) -15 else 0
        val shadows = if (s.crush > .08f) min(45, (s.crush * 260f).roundToInt()) else if (s.p5 < .09f) 14 else 0
        val contrast = ((0.22f - s.std) * 170f).roundToInt().coerceIn(-15, 24)
        val temp = if (!warm && abs(s.cast) > .10f) (-s.cast * 55f).roundToInt().coerceIn(-12, 12) else 0
        val tint = if (abs(s.tintCast) > .06f) (-s.tintCast * 45f).roundToInt().coerceIn(-8, 8) else 0
        val vibrance = vib + (if (s.sat < .22f) 10 else if (s.sat > .55f) -10 else 0)
        val p = HashMap<String, Int>()
        p["exposure"] = exposure
        p["highlights"] = highlights
        p["shadows"] = shadows
        p["contrast"] = contrast
        p["temp"] = temp
        p["tint"] = tint
        p["vibrance"] = vibrance
        p["clarity"] = cla
        p["sharpen"] = shp
        val parts = ArrayList<String>()
        if (exposure != 0) parts.add("Exposição " + String.format("%+.1f", exposure / 40f).replace('.', ',') + " EV")
        if (highlights != 0) parts.add("Realces $highlights")
        if (shadows != 0) parts.add("Sombras +$shadows")
        if (contrast != 0) parts.add("Contraste " + (if (contrast > 0) "+" else "") + contrast)
        if (temp != 0) parts.add("Cor " + (if (temp > 0) "mais quente" else "mais fria"))
        parts.add("Vibração +$vibrance")
        val text = "Cena: $scene. " + parts.joinToString(" · ") + " · look $look."
        return Result(p, look, text)
    }
}
