package pt.enquadra

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Grelha, moldura amarela arredondada, mira central, contagem e etiqueta de estado. */
class Overlay(c: Context) : View(c) {
    var frame: RectF? = null
    var ready = false
    var count = 0
    var label: String? = null
    var onStart: (() -> Unit)? = null
    var onEnd: ((RectF?, Float, Float) -> Unit)? = null
    private val d = c.resources.displayMetrics.density
    private val amber = Color.parseColor("#FFD60A")
    private val green = Color.parseColor("#30D158")
    private val pg = Paint().apply { color = Color.parseColor("#44FFFFFF"); strokeWidth = 1.5f; style = Paint.Style.STROKE }
    private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    private val pb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B3000000") }
    private var x0 = 0f
    private var y0 = 0f
    private var moved = false

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            cv.drawLine(w * i / 3, 0f, w * i / 3, h, pg)
            cv.drawLine(0f, h * i / 3, w, h * i / 3, pg)
        }
        val f = frame
        if (f != null) {
            val col = if (ready) green else amber
            val r = RectF(f.left * w, f.top * h, f.right * w, f.bottom * h)
            pf.color = col
            pf.alpha = 60
            pf.strokeWidth = 10 * d
            cv.drawRoundRect(r, 18 * d, 18 * d, pf)
            pf.color = col
            pf.strokeWidth = 3 * d
            cv.drawRoundRect(r, 18 * d, 18 * d, pf)
            pf.strokeWidth = 2 * d
            cv.drawLine(w / 2 - w * .18f, h / 2, w / 2 + w * .18f, h / 2, pf)
            cv.drawLine(w / 2, h / 2 - 9 * d, w / 2, h / 2 + 9 * d, pf)
        }
        if (count > 0) {
            pt.color = Color.WHITE
            pt.textSize = 56 * d
            cv.drawText(count.toString(), w / 2, h * .38f, pt)
        }
        val lb = label
        if (lb != null) {
            pt.textSize = 13 * d
            val tw = pt.measureText(lb)
            val pad = 14 * d
            cv.drawRoundRect(RectF(w / 2 - tw / 2 - pad, 10 * d, w / 2 + tw / 2 + pad, 40 * d), 15 * d, 15 * d, pb)
            pt.color = if (ready) green else Color.WHITE
            cv.drawText(lb, w / 2, 30 * d, pt)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = max(1f, width.toFloat())
        val h = max(1f, height.toFloat())
        val x = (e.x / w).coerceIn(0f, 1f)
        val y = (e.y / h).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { x0 = x; y0 = y; moved = false }
            MotionEvent.ACTION_MOVE -> {
                if (abs(x - x0) > .04f || abs(y - y0) > .04f) {
                    if (!moved) { moved = true; onStart?.invoke() }
                    val l = min(x0, x)
                    val t = min(y0, y)
                    val side = min(max(abs(x - x0), abs(y - y0)), min(1f - l, 1f - t))
                    frame = RectF(l, t, l + side, t + side)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val f = frame
                if (moved && f != null && f.width() > .1f) onEnd?.invoke(f, x, y)
                else onEnd?.invoke(null, x, y)
            }
        }
        return true
    }
}
