package pt.enquadra

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Grelha, moldura amarela que aparece com animação, rasto tracejado até à mira e etiqueta de estado. */
class Overlay(c: Context) : View(c) {
    var frame: RectF? = null
    var ready = false
    var count = 0
    var label: String? = null
    var onStart: (() -> Unit)? = null
    var onEnd: ((RectF?, Float, Float) -> Unit)? = null
    private val d = c.resources.displayMetrics.density
    private val amber = Color.parseColor("#FFD60A")
    private val green = Color.parseColor("#30D158")
    private val pg = Paint().apply { color = Color.parseColor("#44FFFFFF"); strokeWidth = 1.5f; style = Paint.Style.STROKE }
    private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val pdash = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    private val pb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B3000000") }
    private var x0 = 0f
    private var y0 = 0f
    private var moved = false
    private var shown: RectF? = null
    private var appear = 0f
    private var phase = 0f

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            cv.drawLine(w * i / 3, 0f, w * i / 3, h, pg)
            cv.drawLine(0f, h * i / 3, w, h * i / 3, pg)
        }
        var animate = false
        val tgt = frame
        var f: RectF? = null
        if (tgt != null) {
            val sh = shown
            if (sh == null || moved) shown = RectF(tgt)
            else {
                sh.left += (tgt.left - sh.left) * .3f
                sh.top += (tgt.top - sh.top) * .3f
                sh.right += (tgt.right - sh.right) * .3f
                sh.bottom += (tgt.bottom - sh.bottom) * .3f
                if (abs(tgt.left - sh.left) > .002f || abs(tgt.top - sh.top) > .002f) animate = true
            }
            f = shown
            if (appear < 1f) { appear = min(1f, appear + .09f); animate = true }
        } else {
            shown = null
            appear = 0f
        }
        if (f != null) {
            val e = appear * appear * (3f - 2f * appear)
            val col = if (ready) green else amber
            val bx = (f.left + f.right) / 2 * w
            val by = (f.top + f.bottom) / 2 * h
            val sc = .75f + .25f * e
            val hw = (f.right - f.left) * w / 2 * sc
            val hh = (f.bottom - f.top) * h / 2 * sc
            val r = RectF(bx - hw, by - hh, bx + hw, by + hh)
            val tx = w / 2
            val ty = h / 2
            // rasto tracejado da moldura até à mira (mostra para onde mover o telemóvel)
            if (!ready && e > .5f && hypot(bx - tx, by - ty) > 18 * d) {
                pdash.color = col
                pdash.alpha = 200
                pdash.strokeWidth = 2.5f * d
                pdash.pathEffect = DashPathEffect(floatArrayOf(9 * d, 9 * d), phase)
                cv.drawLine(bx, by, tx, ty, pdash)
                phase -= 1.4f * d
                animate = true
            }
            pf.color = col
            pf.alpha = (60 * e).toInt()
            pf.strokeWidth = 10 * d
            cv.drawRoundRect(r, 18 * d, 18 * d, pf)
            pf.color = col
            pf.alpha = (255 * e).toInt()
            pf.strokeWidth = 3 * d
            cv.drawRoundRect(r, 18 * d, 18 * d, pf)
            pf.strokeWidth = 2 * d
            cv.drawLine(tx - w * .18f, ty, tx + w * .18f, ty, pf)
            cv.drawLine(tx, ty - 9 * d, tx, ty + 9 * d, pf)
        }
        if (count > 0) {
            pt.color = Color.WHITE
            pt.textSize = 56 * d
            cv.drawText(count.toString(), w / 2, h * .38f, pt)
        }
        val lb = label
        if (lb != null) {
            pt.textSize = 13 * d
            val tw = pt.measureText(lb)
            val pad = 14 * d
            cv.drawRoundRect(RectF(w / 2 - tw / 2 - pad, 10 * d, w / 2 + tw / 2 + pad, 40 * d), 15 * d, 15 * d, pb)
            pt.color = if (ready) green else Color.WHITE
            cv.drawText(lb, w / 2, 30 * d, pt)
        }
        if (animate) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = max(1f, width.toFloat())
        val h = max(1f, height.toFloat())
        val x = (e.x / w).coerceIn(0f, 1f)
        val y = (e.y / h).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { x0 = x; y0 = y; moved = false }
            MotionEvent.ACTION_MOVE -> {
                if (abs(x - x0) > .04f || abs(y - y0) > .04f) {
                    if (!moved) { moved = true; onStart?.invoke() }
                    val l = min(x0, x)
                    val t = min(y0, y)
                    val side = min(max(abs(x - x0), abs(y - y0)), min(1f - l, 1f - t))
                    frame = RectF(l, t, l + side, t + side)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val f = frame
                val ok = moved && f != null && f.width() > .1f
                moved = false
                if (ok) onEnd?.invoke(f, x, y)
                else onEnd?.invoke(null, x, y)
            }
        }
        return true
    }
}
