package pt.enquadra

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.Date
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private enum class St { IDLE, SCANNING, FRAMING }

    private val amber = Color.parseColor("#FFD60A")
    private val grey = Color.parseColor("#9A9A9A")
    private lateinit var root: FrameLayout
    private lateinit var camScr: LinearLayout
    private lateinit var edScr: LinearLayout
    private lateinit var wrap: FrameLayout
    private lateinit var pv: PreviewView
    private lateinit var ov: Overlay
    private lateinit var hintTv: TextView
    private lateinit var shBtn: View
    private lateinit var scanBtn: TextView
    private lateinit var galThumb: ImageView
    private lateinit var pro: LinearLayout
    private lateinit var zoomRow: LinearLayout
    private lateinit var capture: ImageCapture
    private val ratioBtns = ArrayList<Button>()
    private var cam: androidx.camera.core.Camera? = null
    private var ratio = 3f / 4f
    private var st = St.IDLE
    private var ready = false
    private var scanStart = 0L
    private var zoomBusy = 0L
    private var boxSide = .38f
    private var dragging = false
    private var torchOn = false
    private var zoomNow = 1f
    private var frame: RectF? = null
    private val guide = Guide()
    @Volatile private var lastIso = 0
    @Volatile private var lastEt = 0L
    private val idleHint = "Toca em ✦ para procurar o enquadramento"

    // editor
    private lateinit var iv: ImageView
    private lateinit var tabsRow: LinearLayout
    private lateinit var ctl: ScrollView
    private lateinit var cropBtn: Button
    private lateinit var undoBtn: Button
    private lateinit var redoBtn: Button
    private var fullBmp: Bitmap? = null
    private var cropBox: RectF? = null
    private var cropOn = false
    private var pb: Bitmap? = null
    private var tb: Bitmap? = null
    private var seed = 1
    private var cur = P()
    private var cap = Cap()
    private var lk = 1
    private var tabN = 0
    private var adjKey = "exposure"
    private var fxKey = "grain"
    private val hist = ArrayList<P>()
    private var hpos = -1
    private var ver = 0
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCam() else toast("Sem permissão da câmara. Podes importar fotos da galeria.")
    }
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.fitsSystemWindows = true
        root.setBackgroundColor(Color.BLACK)
        setContentView(root)
        buildCam()
        buildEd()
        show(0)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCam()
        else perm.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (edScr.visibility == View.VISIBLE) show(0) else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun tv(t: String, sz: Float = 14f) = TextView(this).apply { text = t; textSize = sz; setTextColor(Color.WHITE) }
    private fun pill(fill: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat(); setColor(fill); setStroke(dp(1), stroke)
    }
    private fun btn(t: String, f: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
        background = pill(Color.TRANSPARENT, Color.parseColor("#555555"))
        minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        setPadding(dp(14), dp(4), dp(14), dp(4))
        setOnClickListener { f() }
    }
    private fun styleChip(b: Button, on: Boolean) {
        if (on) { b.background = pill(amber, amber); b.setTextColor(Color.BLACK) }
        else { b.background = pill(Color.TRANSPARENT, Color.parseColor("#555555")); b.setTextColor(Color.WHITE) }
    }
    private fun show(n: Int) {
        camScr.visibility = if (n == 0) View.VISIBLE else View.GONE
        edScr.visibility = if (n == 1) View.VISIBLE else View.GONE
    }
    private fun slider(label: String, mx: Int, init: Int, fmt: (Int) -> String, onStop: (() -> Unit)?, on: (Int) -> Unit): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val l = tv(label, 13f)
        val vt = tv(fmt(init), 13f)
        val sb = SeekBar(this)
        sb.max = mx
        sb.progress = init
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { vt.text = fmt(p); on(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onStop?.invoke() }
        })
        row.addView(l, LinearLayout.LayoutParams(dp(92), -2))
        row.addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(vt, LinearLayout.LayoutParams(dp(54), -2))
        return row
    }

    // ---------- ecrã da câmara ----------
    private fun buildCam() {
        camScr = LinearLayout(this)
        camScr.orientation = LinearLayout.VERTICAL
        pro = LinearLayout(this)
        pro.orientation = LinearLayout.VERTICAL
        pro.visibility = View.GONE
        pro.setPadding(dp(16), dp(4), dp(16), dp(4))
        zoomRow = LinearLayout(this)
        zoomRow.gravity = Gravity.CENTER
        hintTv = tv(idleHint, 13f)
        hintTv.setTextColor(grey)
        hintTv.gravity = Gravity.CENTER
        hintTv.setPadding(dp(8), dp(8), dp(8), dp(8))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(6), dp(8), dp(6))
        val rl = listOf("3:4" to 3f / 4f, "4:5" to 4f / 5f, "1:1" to 1f, "9:16" to 9f / 16f)
        rl.forEachIndexed { i, pr ->
            val lp = LinearLayout.LayoutParams(-2, dp(36))
            lp.marginEnd = dp(6)
            val b = btn(pr.first) {
                ratio = pr.second
                ratioBtns.forEachIndexed { j, bb -> bb.background = pill(Color.TRANSPARENT, if (j == i) amber else Color.parseColor("#555555")) }
                cancelScan()
                layoutPreview()
            }
            b.background = pill(Color.TRANSPARENT, if (i == 0) amber else Color.parseColor("#555555"))
            ratioBtns.add(b)
            top.addView(b, lp)
        }
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        val lpl = LinearLayout.LayoutParams(-2, dp(36))
        lpl.marginEnd = dp(6)
        top.addView(btn("Luz") { torchOn = !torchOn; cam?.cameraControl?.enableTorch(torchOn) }, lpl)
        top.addView(btn("Manual") { pro.visibility = if (pro.visibility == View.VISIBLE) View.GONE else View.VISIBLE }, LinearLayout.LayoutParams(-2, dp(36)))

        wrap = FrameLayout(this)
        pv = PreviewView(this)
        pv.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        pv.scaleType = PreviewView.ScaleType.FILL_CENTER
        ov = Overlay(this)
        wrap.addView(pv, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
        wrap.addView(ov, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
        wrap.viewTreeObserver.addOnGlobalLayoutListener { layoutPreview() }
        ov.onStart = { dragging = true; st = St.FRAMING; ready = false; guide.tpl = null; ov.count = 0 }
        ov.onEnd = { r, x, y ->
            dragging = false
            if (r == null) {
                ov.frame = frame
                focus(x, y)
            } else {
                frame = r
                st = St.FRAMING
                boxSide = r.width()
                pv.bitmap?.let { val (l, _) = guide.lum(it); guide.setTpl(l, r) }
            }
            refreshIcons()
            ov.invalidate()
        }

        shBtn = View(this)
        shBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(dp(4), Color.WHITE) }
        shBtn.setOnClickListener { shoot() }

        galThumb = ImageView(this)
        galThumb.scaleType = ImageView.ScaleType.CENTER_CROP
        galThumb.background = pill(Color.parseColor("#222222"), Color.parseColor("#555555"))
        galThumb.clipToOutline = true
        galThumb.setOnClickListener { picker.launch("image/*") }

        scanBtn = tv("✦", 22f)
        scanBtn.gravity = Gravity.CENTER
        scanBtn.setTextColor(amber)
        scanBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#222222")) }
        scanBtn.setOnClickListener {
            when {
                st == St.IDLE -> startScan()
                st == St.FRAMING && ready -> startScan()
                else -> cancelScan()
            }
        }

        val bot = LinearLayout(this)
        bot.gravity = Gravity.CENTER_VERTICAL
        bot.setPadding(dp(20), dp(8), dp(20), dp(16))
        val left = FrameLayout(this)
        left.addView(galThumb, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.START or Gravity.CENTER_VERTICAL))
        val right = FrameLayout(this)
        right.addView(scanBtn, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.END or Gravity.CENTER_VERTICAL))
        bot.addView(left, LinearLayout.LayoutParams(0, dp(72), 1f))
        bot.addView(shBtn, LinearLayout.LayoutParams(dp(72), dp(72)))
        bot.addView(right, LinearLayout.LayoutParams(0, dp(72), 1f))

        camScr.addView(top, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(wrap, LinearLayout.LayoutParams(-1, 0, 1f))
        camScr.addView(hintTv, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(pro, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(zoomRow, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(bot, LinearLayout.LayoutParams(-1, -2))
        root.addView(camScr, FrameLayout.LayoutParams(-1, -1))
    }

    private fun layoutPreview() {
        val bw = wrap.width
        val bh = wrap.height
        if (bw == 0 || bh == 0) return
        var w = bw
        var hh = (bw / ratio).toInt()
        if (hh > bh) { hh = bh; w = (bh * ratio).toInt() }
        for (v in listOf<View>(pv, ov)) {
            val lp = v.layoutParams as FrameLayout.LayoutParams
            if (lp.width != w || lp.height != hh) {
                lp.width = w; lp.height = hh; lp.gravity = Gravity.CENTER
                v.layoutParams = lp
            }
        }
    }

    private fun glow(ok: Boolean) {
        val c = if (ok) amber else Color.WHITE
        (shBtn.background as GradientDrawable).apply { setColor(c); setStroke(dp(4), c) }
    }

    private fun setHint(t: String, active: Boolean) {
        hintTv.text = t
        hintTv.setTextColor(if (active) amber else grey)
    }

    private fun refreshIcons() {
        scanBtn.text = if (st == St.IDLE) "✦" else if (st == St.FRAMING && ready) "↻" else "✕"
    }

    private fun startScan() {
        st = St.SCANNING
        ready = false
        frame = null
        guide.tpl = null
        guide.resetAcc()
        scanStart = System.currentTimeMillis()
        ov.frame = null
        ov.ready = false
        ov.label = "A procurar o enquadramento…"
        setHint("Mantém o telemóvel parado", true)
        glow(false)
        refreshIcons()
        ov.invalidate()
    }

    private fun cancelScan() {
        st = St.IDLE
        ready = false
        frame = null
        guide.tpl = null
        guide.resetAcc()
        ov.frame = null
        ov.ready = false
        ov.count = 0
        ov.label = null
        setHint(idleHint, false)
        glow(false)
        refreshIcons()
        ov.invalidate()
    }

    private fun evaluate() {
        val f = frame ?: return
        val cx = (f.left + f.right) / 2 - .5f
        val cy = (f.top + f.bottom) / 2 - .5f
        val t = ArrayList<String>()
        if (cx > .06f) t.add("para a direita") else if (cx < -.06f) t.add("para a esquerda")
        if (cy > .06f) t.add("para baixo") else if (cy < -.06f) t.add("para cima")
        val inside = f.left >= -.01f && f.top >= -.01f && f.right <= 1.01f && f.bottom <= 1.01f
        val wasReady = ready
        ready = t.isEmpty() && inside
        ov.ready = ready
        ov.label = if (ready) "Pronto" else "A enquadrar…"
        if (ready) setHint("Alinhado. Dispara", true)
        else if (t.isEmpty()) setHint("Afasta-te um pouco para caber a moldura", true)
        else setHint("Move o telemóvel " + t.joinToString(" e "), true)
        glow(ready)
        if (wasReady != ready) refreshIcons()
    }

    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (e: Exception) { }
            ui.postDelayed(this, 120)
        }
    }

    private fun step() {
        if (camScr.visibility != View.VISIBLE || dragging || cam == null) return
        if (st == St.IDLE) return
        val bmp = pv.bitmap ?: return
        val (l, s) = guide.lum(bmp)
        val now = System.currentTimeMillis()
        if (st == St.SCANNING) {
            guide.accumulate(l, s)
            val left = 3000L - (now - scanStart)
            ov.count = ceil(left / 1000.0).toInt().coerceIn(0, 3)
            if (left <= 0L) {
                val r = guide.pick(boxSide)
                if (r == null) { cancelScan(); return }
                frame = r
                guide.setTpl(l, r)
                st = St.FRAMING
                ov.count = 0
                refreshIcons()
                autoZoom()
            }
        } else if (st == St.FRAMING) {
            if (now < zoomBusy) return
            val f = frame
            if (f != null && guide.tpl != null) frame = guide.track(l, f)
            evaluate()
        }
        ov.frame = frame
        ov.invalidate()
    }

    private fun autoZoom() {
        val c = cam ?: return
        val zs = c.cameraInfo.zoomState.value ?: return
        val f = frame ?: return
        val target = (zoomNow * (.6f / max(.05f, f.width()))).coerceIn(zs.minZoomRatio, min(zs.maxZoomRatio, 8f))
        val t = (target * 10).roundToInt() / 10f
        if (t / zoomNow < 1.12f) return
        applyZoom(t)
    }

    private fun applyZoom(target: Float) {
        val c = cam ?: return
        val k = target / zoomNow
        c.cameraControl.setZoomRatio(target)
        zoomNow = target
        updateZoomChips()
        if (st == St.FRAMING && frame != null) {
            zoomBusy = System.currentTimeMillis() + 800
            ui.postDelayed({
                val f = frame
                if (f != null) {
                    val nf = RectF(.5f + (f.left - .5f) * k, .5f + (f.top - .5f) * k, .5f + (f.right - .5f) * k, .5f + (f.bottom - .5f) * k)
                    frame = nf
                    pv.bitmap?.let { val (l, _) = guide.lum(it); guide.setTpl(l, nf) }
                }
            }, 500)
        }
    }

    private fun updateZoomChips() {
        val c = cam ?: return
        val zs = c.cameraInfo.zoomState.value ?: return
        zoomRow.removeAllViews()
        val list = ArrayList<Float>()
        for (q in listOf(.5f, 1f, 2f, 5f)) if (q >= zs.minZoomRatio - .01f && q <= zs.maxZoomRatio) list.add(q)
        val cur1 = (zoomNow * 10).roundToInt() / 10f
        if (list.none { abs(it - cur1) < .05f }) list.add(cur1)
        list.sort()
        for (q in list) {
            val lab = if (q == q.toInt().toFloat()) q.toInt().toString() else q.toString()
            val b = btn("$lab×") { applyZoom(q) }
            styleChip(b, abs(q - cur1) < .05f)
            val lp = LinearLayout.LayoutParams(-2, dp(34))
            lp.marginEnd = dp(8)
            zoomRow.addView(b, lp)
        }
    }

    private fun focus(x: Float, y: Float) {
        val c = cam ?: return
        try {
            val pt = pv.meteringPointFactory.createPoint(x * pv.width, y * pv.height)
            c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
        } catch (e: Exception) { }
    }

    private fun startCam() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val prov = f.get()
            val pbd = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3)
            Camera2Interop.Extender<Preview>(pbd).setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
                    result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastEt = it }
                }
            })
            val prev = pbd.build()
            prev.setSurfaceProvider(pv.surfaceProvider)
            capture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            prov.unbindAll()
            cam = prov.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, prev, capture)
            zoomNow = 1f
            setupControls()
            ui.post(tick)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupControls() {
        val c = cam ?: return
        pro.removeAllViews()
        updateZoomChips()
        val es = c.cameraInfo.exposureState
        if (es.isExposureCompensationSupported) {
            val r = es.exposureCompensationRange
            val step = es.exposureCompensationStep.toFloat()
            pro.addView(slider("Exposição", r.upper - r.lower, -r.lower, { String.format("%.1f", (it + r.lower) * step) }, null) {
                c.cameraControl.setExposureCompensationIndex(it + r.lower)
            })
        }
        try {
            val ci = Camera2CameraInfo.from(c.cameraInfo)
            val ir = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
            val er = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            if (ir != null && er != null) {
                val isoMin = max(ir.lower, 50)
                val isoMax = min(ir.upper, 3200)
                val etMin = max(er.lower, 125000L)
                val etMax = min(er.upper, 500000000L)
                var curIso = if (lastIso > 0) lastIso.coerceIn(isoMin, isoMax) else 100.coerceIn(isoMin, isoMax)
                var curEt = if (lastEt > 0) lastEt.coerceIn(etMin, etMax) else 10000000L.coerceIn(etMin, etMax)
                fun manual() {
                    Camera2CameraControl.from(c.cameraControl).setCaptureRequestOptions(
                        CaptureRequestOptions.Builder()
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                            .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, curIso)
                            .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, curEt)
                            .build()
                    )
                }
                val li = ln(isoMin.toDouble())
                val ri = ln(isoMax.toDouble())
                val le = ln(etMin.toDouble())
                val re = ln(etMax.toDouble())
                val p0 = (100 * (ln(curIso.toDouble()) - li) / (ri - li)).roundToInt()
                val p1 = (100 * (ln(curEt.toDouble()) - le) / (re - le)).roundToInt()
                pro.addView(slider("ISO", 100, p0, { exp(li + it / 100.0 * (ri - li)).roundToInt().toString() }, null) {
                    curIso = exp(li + it / 100.0 * (ri - li)).roundToInt().coerceIn(isoMin, isoMax); manual()
                })
                pro.addView(slider("Obturador", 100, p1, { "1/" + (1e9 / exp(le + it / 100.0 * (re - le))).roundToInt() }, null) {
                    curEt = exp(le + it / 100.0 * (re - le)).toLong().coerceIn(etMin, etMax); manual()
                })
                pro.addView(btn("Automático") {
                    Camera2CameraControl.from(c.cameraControl).clearCaptureRequestOptions()
                    setupControls()
                })
            }
        } catch (e: Exception) { }
    }

    private fun cropRatio(b: Bitmap, r: Float): Bitmap {
        val w = b.width
        val hh = b.height
        return if (w / hh.toFloat() > r) {
            val nw = (hh * r).toInt()
            Bitmap.createBitmap(b, (w - nw) / 2, 0, nw, hh)
        } else {
            val nh = (w / r).toInt()
            Bitmap.createBitmap(b, 0, (hh - nh) / 2, w, nh)
        }
    }

    private fun shoot() {
        val box = if (st == St.FRAMING && ready) frame?.let { RectF(it) } else null
        shBtn.isEnabled = false
        capture.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = image.toBitmap()
                    image.close()
                    val m = Matrix()
                    m.postRotate(rot.toFloat())
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    bmp = Film.scaled(cropRatio(bmp, ratio), 3200)
                    cap = Cap(zoomNow, lastIso, lastEt, Date(), Build.MANUFACTURER + " " + Build.MODEL)
                    cancelScan()
                    openEditor(bmp, box)
                } catch (e: Exception) {
                    toast("Erro ao processar a fotografia: " + e.javaClass.simpleName)
                }
                shBtn.isEnabled = true
            }
            override fun onError(exception: ImageCaptureException) {
                toast("Não foi possível fotografar")
                shBtn.isEnabled = true
            }
        })
    }

    private fun importUri(uri: Uri) {
        try {
            val s = ImageDecoder.createSource(contentResolver, uri)
            val bm = ImageDecoder.decodeBitmap(s) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val mx = max(info.size.width, info.size.height)
                if (mx > 3200) dec.setTargetSampleSize(mx / 3200 + 1)
            }
            cap = Cap(date = Date(), model = Build.MANUFACTURER + " " + Build.MODEL)
            openEditor(bm, null)
        } catch (e: Exception) {
            toast("Não foi possível abrir a imagem")
        }
    }

    // ---------- editor ----------
    private fun buildEd() {
        edScr = LinearLayout(this)
        edScr.orientation = LinearLayout.VERTICAL
        edScr.setBackgroundColor(Color.parseColor("#0B0B0B"))
        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setPadding(dp(12), dp(12), dp(12), dp(8))
        edScr.addView(iv, LinearLayout.LayoutParams(-1, 0, 1f))

        cropBtn = btn("Recorte da moldura: sim") {
            cropOn = !cropOn
            rebuildBase()
            updateCropBtn()
            showTab(tabN)
            redraw()
        }
        val cl = LinearLayout.LayoutParams(-2, dp(34))
        cl.gravity = Gravity.CENTER_HORIZONTAL
        cl.bottomMargin = dp(6)
        edScr.addView(cropBtn, cl)

        tabsRow = LinearLayout(this)
        tabsRow.gravity = Gravity.CENTER
        tabsRow.background = pill(Color.parseColor("#1C1C1E"), Color.TRANSPARENT)
        tabsRow.setPadding(dp(4), dp(3), dp(4), dp(3))
        listOf("Looks", "Ajustes", "Efeitos", "Molduras").forEachIndexed { i, n ->
            tabsRow.addView(btn(n) { showTab(i) }, LinearLayout.LayoutParams(-2, dp(34)))
        }
        val tl = LinearLayout.LayoutParams(-2, -2)
        tl.gravity = Gravity.CENTER_HORIZONTAL
        edScr.addView(tabsRow, tl)

        ctl = ScrollView(this)
        edScr.addView(ctl, LinearLayout.LayoutParams(-1, dp(150)))

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(16), dp(6), dp(16), dp(14))
        bar.addView(btn("Excluir") { show(0) })
        bar.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        undoBtn = btn("↶") { undo() }
        redoBtn = btn("↷") { redo() }
        bar.addView(undoBtn)
        bar.addView(redoBtn)
        bar.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        val sv = btn("✓ Guardar") { save() }
        sv.background = pill(amber, amber)
        sv.setTextColor(Color.BLACK)
        bar.addView(sv)
        edScr.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(edScr, FrameLayout.LayoutParams(-1, -1))
    }

    private fun updateCropBtn() {
        cropBtn.visibility = if (cropBox != null) View.VISIBLE else View.GONE
        cropBtn.text = if (cropOn) "Recorte da moldura: sim" else "Recorte da moldura: não"
    }

    private fun pushHist() {
        while (hist.size > hpos + 1) hist.removeAt(hist.size - 1)
        hist.add(cur.copy())
        hpos = hist.size - 1
        undoBtn.alpha = if (hpos > 0) 1f else .4f
        redoBtn.alpha = .4f
    }

    private fun undo() {
        if (hpos <= 0) return
        hpos--
        restoreHist()
    }

    private fun redo() {
        if (hpos >= hist.size - 1) return
        hpos++
        restoreHist()
    }

    private fun restoreHist() {
        cur = hist[hpos].copy()
        undoBtn.alpha = if (hpos > 0) 1f else .4f
        redoBtn.alpha = if (hpos < hist.size - 1) 1f else .4f
        showTab(tabN)
        redraw()
    }

    private fun curSrc(): Bitmap {
        val s = fullBmp ?: throw IllegalStateException("sem imagem")
        val b = cropBox
        if (!cropOn || b == null) return s
        val side = min(1f, b.width() * 1.24f)
        val cx = (b.left + b.right) / 2
        val cy = (b.top + b.bottom) / 2
        val l = (cx - side / 2).coerceIn(0f, 1f - side)
        val t = (cy - side / 2).coerceIn(0f, 1f - side)
        val x = (l * s.width).toInt().coerceIn(0, s.width - 2)
        val y = (t * s.height).toInt().coerceIn(0, s.height - 2)
        val w = (side * s.width).toInt().coerceIn(2, s.width - x)
        val hh = (side * s.height).toInt().coerceIn(2, s.height - y)
        return Bitmap.createBitmap(s, x, y, w, hh)
    }

    private fun rebuildBase() {
        val s = curSrc()
        pb = Film.scaled(s, 900)
        tb = Film.scaled(s, 110)
    }

    private fun openEditor(b: Bitmap, box: RectF?) {
        fullBmp = b
        cropBox = box
        cropOn = box != null
        seed = Random.nextInt(1, Int.MAX_VALUE)
        lk = 1
        cur = LOOKS[1].toP(null)
        hist.clear()
        hpos = -1
        rebuildBase()
        updateCropBtn()
        show(1)
        pushHist()
        showTab(0)
        redraw()
    }

    private fun showTab(n: Int) {
        tabN = n
        for (i in 0 until tabsRow.childCount) {
            val b = tabsRow.getChildAt(i)
            b.background = pill(if (i == n) Color.parseColor("#3A3A3C") else Color.TRANSPARENT, Color.TRANSPARENT)
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(6), dp(14), dp(6))
        when (n) {
            0 -> {
                val hs = HorizontalScrollView(this)
                val row = LinearLayout(this)
                val thumb = tb
                LOOKS.forEachIndexed { i, lo ->
                    val col = LinearLayout(this)
                    col.orientation = LinearLayout.VERTICAL
                    col.gravity = Gravity.CENTER
                    col.setPadding(dp(5), dp(5), dp(5), dp(5))
                    if (i == lk) col.background = pill(Color.TRANSPARENT, amber)
                    val im = ImageView(this)
                    im.scaleType = ImageView.ScaleType.CENTER_CROP
                    if (thumb != null) im.setImageBitmap(Film.render(thumb, lo.toP(null), seed))
                    col.addView(im, LinearLayout.LayoutParams(dp(66), dp(88)))
                    col.addView(tv(lo.name, 12f))
                    col.setOnClickListener { lk = i; cur = lo.toP(cur); pushHist(); showTab(0); redraw() }
                    row.addView(col)
                }
                hs.addView(row)
                box.addView(hs)
            }
            1, 2 -> {
                val list = if (n == 1) ADJ else FX
                var key = if (n == 1) adjKey else fxKey
                if (list.none { it.first == key }) key = list[0].first
                val kk = key
                val hs = HorizontalScrollView(this)
                val row = LinearLayout(this)
                for ((k, lab) in list) {
                    val lp = LinearLayout.LayoutParams(-2, dp(34))
                    lp.marginEnd = dp(8)
                    val b = btn(lab) { if (n == 1) adjKey = k else fxKey = k; showTab(n) }
                    styleChip(b, k == kk)
                    row.addView(b, lp)
                }
                hs.addView(row)
                box.addView(hs)
                val off = if (n == 1 && kk != "fade") 100 else 0
                val title = list.first { it.first == kk }.second
                box.addView(slider(title, if (off > 0) 200 else 100, cur.g(kk) + off, { (it - off).toString() }, { pushHist() }) {
                    cur.a[kk] = it - off
                    redraw()
                })
            }
            else -> {
                val hs = HorizontalScrollView(this)
                val row = LinearLayout(this)
                for ((k, lab) in FR) {
                    val lp = LinearLayout.LayoutParams(-2, dp(34))
                    lp.marginEnd = dp(8)
                    val b = btn(lab) { cur.frame = k; pushHist(); showTab(3); redraw() }
                    styleChip(b, cur.frame == k)
                    row.addView(b, lp)
                }
                hs.addView(row)
                box.addView(hs)
                val db = btn(if (cur.date) "Carimbo de data: sim" else "Carimbo de data: não") {
                    cur.date = !cur.date; pushHist(); showTab(3); redraw()
                }
                styleChip(db, cur.date)
                val dl = LinearLayout.LayoutParams(-2, dp(34))
                dl.topMargin = dp(12)
                box.addView(db, dl)
            }
        }
        ctl.removeAllViews()
        ctl.addView(box)
    }

    private fun redraw() {
        val base = pb ?: return
        val v = ++ver
        val pc = cur.copy()
        val cp = cap
        val sd = seed
        worker.execute {
            try {
                if (v != ver) return@execute
                val o = Film.compose(Film.render(base, pc, sd), pc, cp)
                runOnUiThread { if (v == ver) iv.setImageBitmap(o) }
            } catch (e: Exception) {
                runOnUiThread { toast("Erro na revelação: " + e.javaClass.simpleName) }
            }
        }
    }

    private fun save() {
        val s = try { curSrc() } catch (e: Exception) { return }
        val pc = cur.copy()
        val cp = cap
        val sd = seed
        toast("A guardar…")
        worker.execute {
            try {
                val o = Film.compose(Film.render(Film.scaled(s, 2600), pc, sd), pc, cp)
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, "Enquadra_" + System.currentTimeMillis() + ".jpg")
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Enquadra")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { o.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                val th = Film.scaled(o, 160)
                runOnUiThread {
                    galThumb.setImageBitmap(th)
                    toast("Guardada na galeria (pasta Enquadra)")
                    show(0)
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Não foi possível guardar") }
            }
        }
    }
}
