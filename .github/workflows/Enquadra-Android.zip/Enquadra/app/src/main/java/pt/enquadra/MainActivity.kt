package pt.enquadra

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.content.res.ColorStateList
import android.widget.PopupMenu
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Date
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private enum class St { IDLE, SCANNING, FRAMING }

    private val amber = Color.parseColor("#FFD60A")
    private val grey = Color.parseColor("#9A9A9A")
    private lateinit var root: FrameLayout
    private lateinit var camScr: LinearLayout
    private lateinit var edScr: LinearLayout
    private lateinit var wrap: FrameLayout
    private lateinit var pv: PreviewView
    private lateinit var ov: Overlay
    private lateinit var hintTv: TextView
    private lateinit var shBtn: View
    private lateinit var scanBtn: TextView
    private lateinit var galThumb: ImageView
    private lateinit var pro: LinearLayout
    private lateinit var zoomRow: LinearLayout
    private lateinit var capture: ImageCapture
    private val ratioBtns = ArrayList<Button>()
    private var cam: androidx.camera.core.Camera? = null
    private var ratio = 3f / 4f
    private var st = St.IDLE
    private var ready = false
    private var scanStart = 0L
    private var zoomBusy = 0L
    private var boxSide = .38f
    private var dragging = false
    private var torchOn = false
    private var zoomNow = 1f
    private var frame: RectF? = null
    private val guide = Guide()
    @Volatile private var lastIso = 0
    @Volatile private var lastEt = 0L
    private val idleHint = "Toca em ✦ para procurar o enquadramento"
    private var manualMode = false
    private lateinit var ratioBtn: Button
    private lateinit var flashBtn: ImageView
    private lateinit var shRing: View
    private lateinit var shCore: View
    private lateinit var flyView: ImageView
    private lateinit var flashView: View
    private var autoZoomed = false
    private var origBytes: ByteArray? = null
    private lateinit var manualBtn: Button
    private var detector: ObjectDetector? = null
    private var labeler: ImageLabeler? = null
    private val busy = AtomicBoolean(false)
    private val analysis = Executors.newSingleThreadExecutor()
    private var lastDet = 0L
    private var trackId = -1
    private var subject = "Motivo"
    private var reTpl = false
    private var lastBmp: Bitmap? = null
    private val cands = HashMap<Int, Cand>()

    private class Det(val box: RectF, val id: Int, val label: String)
    private class Cand(var box: RectF, var label: String, var score: Float, var n: Int, val id: Int)
    private val ptLabels = mapOf(
        "Sky" to "Céu", "Cloud" to "Nuvens", "Sunset" to "Pôr do sol", "Beach" to "Praia", "Sea" to "Mar", "Ocean" to "Oceano",
        "Water" to "Água", "Wave" to "Onda", "Mountain" to "Montanha", "Tree" to "Árvore", "Palm tree" to "Palmeira",
        "Plant" to "Planta", "Flower" to "Flor", "Leaf" to "Folha", "Grass" to "Erva", "Forest" to "Floresta", "Bird" to "Ave",
        "Cat" to "Gato", "Dog" to "Cão", "Building" to "Edifício", "Skyscraper" to "Arranha-céus", "Tower" to "Torre",
        "Bridge" to "Ponte", "Road" to "Estrada", "Street" to "Rua", "Car" to "Carro", "Vehicle" to "Veículo",
        "Bicycle" to "Bicicleta", "Boat" to "Barco", "Face" to "Rosto", "Smile" to "Sorriso", "Hand" to "Mão",
        "Hair" to "Cabelo", "Food" to "Comida", "Fruit" to "Fruta", "Coffee" to "Café", "Cup" to "Chávena",
        "Table" to "Mesa", "Chair" to "Cadeira", "Furniture" to "Mobília", "Window" to "Janela", "Door" to "Porta",
        "House" to "Casa", "Architecture" to "Arquitetura", "City" to "Cidade", "Snow" to "Neve", "Sand" to "Areia",
        "Rock" to "Rocha", "Sculpture" to "Escultura", "Statue" to "Estátua", "Church" to "Igreja", "Clock" to "Relógio",
        "Book" to "Livro", "Shoe" to "Sapato", "Flowerpot" to "Vaso", "Sofa" to "Sofá", "Pillow" to "Almofada"
    )

    // editor
    private lateinit var iv: ImageView
    private lateinit var tabsRow: LinearLayout
    private lateinit var ctl: ScrollView
    private lateinit var cropBtn: Button
    private lateinit var undoBtn: Button
    private lateinit var redoBtn: Button
    private var fullBmp: Bitmap? = null
    private var cropBox: RectF? = null
    private var cropOn = false
    private var pb: Bitmap? = null
    private var tb: Bitmap? = null
    private var seed = 1
    private var cur = P()
    private var cap = Cap()
    private var lk = 1
    private var tabN = 0
    private var adjKey = "exposure"
    private var fxKey = "grain"
    private val hist = ArrayList<P>()
    private var hpos = -1
    private var ver = 0
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCam() else toast("Sem permissão da câmara. Podes importar fotos da galeria.")
    }
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.fitsSystemWindows = true
        root.setBackgroundColor(Color.BLACK)
        setContentView(root)
        buildCam()
        buildEd()
        show(0)
        try {
            detector = ObjectDetection.getClient(
                ObjectDetectorOptions.Builder().setDetectorMode(ObjectDetectorOptions.STREAM_MODE).enableMultipleObjects().enableClassification().build()
            )
            labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        } catch (e: Exception) { }
        ui.post(tick)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCam()
        else perm.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (edScr.visibility == View.VISIBLE) show(0) else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun tv(t: String, sz: Float = 14f) = TextView(this).apply { text = t; textSize = sz; setTextColor(Color.WHITE) }
    private fun pill(fill: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat(); setColor(fill); setStroke(dp(1), stroke)
    }
    private val glass = Color.parseColor("#22FFFFFF")
    private val glassLine = Color.parseColor("#33FFFFFF")
    private fun medium() = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private fun haptic(v: View) { v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
    private fun roundOutline(r: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, r.toFloat()) }
    }
    private fun btn(t: String, f: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE); typeface = medium()
        background = pill(glass, glassLine)
        minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        setPadding(dp(14), dp(4), dp(14), dp(4))
        setOnClickListener { haptic(this); f() }
    }
    private fun styleChip(b: Button, on: Boolean) {
        if (on) { b.background = pill(amber, amber); b.setTextColor(Color.BLACK) }
        else { b.background = pill(glass, glassLine); b.setTextColor(Color.WHITE) }
    }
    private fun show(n: Int) {
        camScr.animate().cancel()
        edScr.animate().cancel()
        flyView.animate().cancel()
        camScr.alpha = 1f
        edScr.alpha = 1f
        flyView.visibility = View.GONE
        camScr.visibility = if (n == 0) View.VISIBLE else View.GONE
        edScr.visibility = if (n == 1) View.VISIBLE else View.GONE
    }
    private fun slider(label: String, mx: Int, init: Int, fmt: (Int) -> String, onStop: (() -> Unit)?, neutral: Int = -1, on: (Int) -> Unit): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val l = tv(label, 13f)
        val vt = tv(fmt(init), 13f)
        vt.gravity = Gravity.END
        vt.setTextColor(grey)
        val sb = SeekBar(this)
        sb.max = mx
        sb.progress = init
        sb.progressTintList = ColorStateList.valueOf(amber)
        sb.thumbTintList = ColorStateList.valueOf(amber)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#44FFFFFF"))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { vt.text = fmt(p); on(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onStop?.invoke() }
        })
        if (neutral >= 0) l.setOnClickListener { sb.progress = neutral; onStop?.invoke() }
        row.addView(l, LinearLayout.LayoutParams(dp(96), -2))
        row.addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(vt, LinearLayout.LayoutParams(dp(46), -2))
        return row
    }

    // ---------- ecrã da câmara ----------
    private fun showRatioMenu() {
        val pm = PopupMenu(this, ratioBtn)
        val items = listOf("3:4" to 3f / 4f, "4:5" to 4f / 5f, "1:1" to 1f, "9:16" to 9f / 16f)
        items.forEachIndexed { i, pr -> pm.menu.add(0, i, i, pr.first) }
        pm.setOnMenuItemClickListener { mi ->
            val pr = items[mi.itemId]
            ratio = pr.second
            ratioBtn.text = pr.first + "  ▾"
            cancelScan()
            layoutPreview()
            true
        }
        pm.show()
    }

    private fun flash() {
        flashView.animate().cancel()
        flashView.alpha = 0f
        flashView.animate().alpha(.75f).setDuration(50).withEndAction { flashView.animate().alpha(0f).setDuration(180).start() }.start()
    }

    private fun buildCam() {
        camScr = LinearLayout(this)
        camScr.orientation = LinearLayout.VERTICAL
        camScr.setBackgroundColor(Color.BLACK)
        pro = LinearLayout(this)
        pro.orientation = LinearLayout.VERTICAL
        pro.visibility = View.GONE
        pro.setPadding(dp(16), dp(4), dp(16), dp(4))
        zoomRow = LinearLayout(this)
        zoomRow.gravity = Gravity.CENTER
        hintTv = tv(idleHint, 13f)
        hintTv.setTextColor(grey)
        hintTv.typeface = medium()
        hintTv.gravity = Gravity.CENTER
        hintTv.setPadding(dp(8), dp(10), dp(8), dp(8))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(14), dp(8), dp(14), dp(8))
        ratioBtn = btn("3:4  ▾") { showRatioMenu() }
        top.addView(ratioBtn, LinearLayout.LayoutParams(-2, dp(36)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        flashBtn = ImageView(this)
        flashBtn.setImageResource(R.drawable.ic_flash)
        flashBtn.setColorFilter(Color.WHITE)
        flashBtn.setPadding(dp(9), dp(8), dp(9), dp(8))
        flashBtn.background = pill(glass, glassLine)
        flashBtn.setOnClickListener {
            haptic(flashBtn)
            torchOn = !torchOn
            cam?.cameraControl?.enableTorch(torchOn)
            flashBtn.setColorFilter(if (torchOn) amber else Color.WHITE)
        }
        val fl = LinearLayout.LayoutParams(dp(44), dp(36))
        fl.marginEnd = dp(8)
        top.addView(flashBtn, fl)
        manualBtn = btn("Manual") {
            manualMode = !manualMode
            pro.visibility = if (manualMode) View.VISIBLE else View.GONE
            styleChip(manualBtn, manualMode)
            startCam()
        }
        top.addView(manualBtn, LinearLayout.LayoutParams(-2, dp(36)))

        wrap = FrameLayout(this)
        pv = PreviewView(this)
        pv.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        pv.scaleType = PreviewView.ScaleType.FILL_CENTER
        pv.outlineProvider = roundOutline(dp(22))
        pv.clipToOutline = true
        ov = Overlay(this)
        wrap.addView(pv, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
        wrap.addView(ov, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
        wrap.viewTreeObserver.addOnGlobalLayoutListener { layoutPreview() }
        ov.onStart = { dragging = true; st = St.FRAMING; ready = false; guide.tpl = null; ov.count = 0 }
        ov.onEnd = { r, x, y ->
            dragging = false
            if (r == null) {
                ov.frame = frame
                focus(x, y)
            } else {
                frame = r
                st = St.FRAMING
                boxSide = r.width()
                pv.bitmap?.let { val (l, _) = guide.lum(it); guide.setTpl(l, r) }
            }
            refreshIcons()
            ov.invalidate()
        }

        shRing = View(this)
        shRing.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(3), Color.WHITE) }
        shCore = View(this)
        shCore.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        val shWrap = FrameLayout(this)
        shWrap.addView(shRing, FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER))
        shWrap.addView(shCore, FrameLayout.LayoutParams(dp(62), dp(62), Gravity.CENTER))
        shWrap.setOnTouchListener { _, e ->
            if (shBtn.isEnabled) {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> shCore.animate().scaleX(.88f).scaleY(.88f).setDuration(70).start()
                    MotionEvent.ACTION_UP -> { shCore.animate().scaleX(1f).scaleY(1f).setDuration(120).start(); shoot() }
                    MotionEvent.ACTION_CANCEL -> shCore.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
            }
            true
        }
        shBtn = shWrap

        galThumb = ImageView(this)
        galThumb.scaleType = ImageView.ScaleType.CENTER_CROP
        galThumb.background = pill(Color.parseColor("#222222"), glassLine)
        galThumb.clipToOutline = true
        galThumb.setOnClickListener { picker.launch("image/*") }

        scanBtn = tv("✦", 22f)
        scanBtn.gravity = Gravity.CENTER
        scanBtn.setTextColor(amber)
        scanBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(glass); setStroke(dp(1), glassLine) }
        scanBtn.setOnClickListener {
            haptic(scanBtn)
            when {
                st == St.IDLE -> startScan()
                st == St.FRAMING && ready -> startScan()
                else -> cancelScan()
            }
        }

        val bot = LinearLayout(this)
        bot.gravity = Gravity.CENTER_VERTICAL
        bot.setPadding(dp(20), dp(8), dp(20), dp(18))
        val left = FrameLayout(this)
        left.addView(galThumb, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.START or Gravity.CENTER_VERTICAL))
        val right = FrameLayout(this)
        right.addView(scanBtn, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.END or Gravity.CENTER_VERTICAL))
        bot.addView(left, LinearLayout.LayoutParams(0, dp(76), 1f))
        bot.addView(shBtn, LinearLayout.LayoutParams(dp(76), dp(76)))
        bot.addView(right, LinearLayout.LayoutParams(0, dp(76), 1f))

        camScr.addView(top, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(wrap, LinearLayout.LayoutParams(-1, 0, 1f))
        camScr.addView(hintTv, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(pro, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(zoomRow, LinearLayout.LayoutParams(-1, -2))
        camScr.addView(bot, LinearLayout.LayoutParams(-1, -2))
        root.addView(camScr, FrameLayout.LayoutParams(-1, -1))
    }

    private fun layoutPreview() {
        val bw = wrap.width
        val bh = wrap.height
        if (bw == 0 || bh == 0) return
        var w = bw
        var hh = (bw / ratio).toInt()
        if (hh > bh) { hh = bh; w = (bh * ratio).toInt() }
        for (v in listOf<View>(pv, ov)) {
            val lp = v.layoutParams as FrameLayout.LayoutParams
            if (lp.width != w || lp.height != hh) {
                lp.width = w; lp.height = hh; lp.gravity = Gravity.CENTER
                v.layoutParams = lp
            }
        }
    }

    private fun glow(ok: Boolean) {
        val c = if (ok) amber else Color.WHITE
        (shCore.background as GradientDrawable).setColor(c)
        (shRing.background as GradientDrawable).setStroke(dp(3), c)
    }

    private fun setHint(t: String, active: Boolean) {
        hintTv.text = t
        hintTv.setTextColor(if (active) amber else grey)
    }

    private fun refreshIcons() {
        scanBtn.text = if (st == St.IDLE) "✦" else if (st == St.FRAMING && ready) "↻" else "✕"
    }

    private fun startScan() {
        resetAutoZoom()
        st = St.SCANNING
        ready = false
        frame = null
        guide.tpl = null
        guide.resetAcc()
        cands.clear()
        trackId = -1
        subject = "Motivo"
        scanStart = System.currentTimeMillis()
        ov.frame = null
        ov.ready = false
        ov.label = "A procurar o enquadramento…"
        setHint("Mantém o telemóvel parado", true)
        glow(false)
        refreshIcons()
        ov.invalidate()
    }

    private fun cancelScan() {
        resetAutoZoom()
        st = St.IDLE
        ready = false
        frame = null
        guide.tpl = null
        guide.resetAcc()
        cands.clear()
        trackId = -1
        ov.frame = null
        ov.ready = false
        ov.count = 0
        ov.label = null
        setHint(idleHint, false)
        glow(false)
        refreshIcons()
        ov.invalidate()
    }

    private fun resetAutoZoom() {
        if (!autoZoomed) return
        autoZoomed = false
        val c = cam ?: return
        c.cameraControl.setZoomRatio(1f)
        zoomNow = 1f
        updateZoomChips()
    }

    private fun evaluate(l: FloatArray?) {
        val f = frame ?: return
        val cx = (f.left + f.right) / 2 - .5f
        val cy = (f.top + f.bottom) / 2 - .5f
        val t = ArrayList<String>()
        if (cx > .06f) t.add("para a direita") else if (cx < -.06f) t.add("para a esquerda")
        if (cy > .06f) t.add("para baixo") else if (cy < -.06f) t.add("para cima")
        val inside = f.left >= -.01f && f.top >= -.01f && f.right <= 1.01f && f.bottom <= 1.01f
        val wasReady = ready
        ready = t.isEmpty() && inside
        ov.ready = ready
        ov.label = if (ready) subject + "  ·  Pronto" else subject
        val dark = l != null && guide.brightness(l) < .2f
        if (ready) setHint(if (dark) "Alinhado. Pouca luz: segura bem o telemóvel" else "Alinhado. Dispara", true)
        else if (t.isEmpty()) setHint("Afasta-te um pouco para caber a moldura", true)
        else setHint("Move o telemóvel " + t.joinToString(" e "), true)
        glow(ready)
        if (wasReady != ready) refreshIcons()
    }

    private val tick = object : Runnable {
        override fun run() {
            try { tickOnce() } catch (e: Exception) { busy.set(false) }
            ui.postDelayed(this, 150)
        }
    }

    private fun tickOnce() {
        if (camScr.visibility != View.VISIBLE || dragging || cam == null || st == St.IDLE) return
        if (busy.get()) return
        val bmp = pv.bitmap ?: return
        busy.set(true)
        val now = System.currentTimeMillis()
        val doDet = detector != null && ((st == St.SCANNING && now - lastDet > 300) || (st == St.FRAMING && trackId >= 0 && now - lastDet > 600))
        if (doDet) lastDet = now
        analysis.execute {
            try {
                val (l, s) = guide.lum(bmp)
                if (doDet) detect(Film.scaled(bmp, 480))
                ui.post { onFrame(l, s, bmp); busy.set(false) }
            } catch (e: Exception) {
                busy.set(false)
            }
        }
    }

    private fun detect(small: Bitmap) {
        val det = detector ?: return
        val w = small.width.toFloat()
        val hh = small.height.toFloat()
        det.process(InputImage.fromBitmap(small, 0)).addOnSuccessListener { list ->
            val out = ArrayList<Det>()
            for (o in list) {
                val r = o.boundingBox
                var lab = "Motivo"
                var best = 0f
                for (lb in o.labels) {
                    if (lb.confidence >= best) {
                        best = lb.confidence
                        lab = when (lb.text) {
                            "Home good" -> "Objeto"
                            "Fashion good" -> "Moda"
                            "Food" -> "Comida"
                            "Place" -> "Local"
                            "Plant" -> "Planta"
                            else -> "Motivo"
                        }
                    }
                }
                val id = o.trackingId ?: -1
                out.add(Det(RectF(r.left / w, r.top / hh, r.right / w, r.bottom / hh), id, lab))
            }
            onDetections(out)
        }.addOnFailureListener { }
    }

    private fun boxFor(b: RectF): RectF {
        val cx = (b.left + b.right) / 2
        val cy = (b.top + b.bottom) / 2
        val side = (max(b.width(), b.height()) * 1.3f).coerceIn(.28f, .9f)
        val l = (cx - side / 2).coerceIn(0f, 1f - side)
        val t = (cy - side / 2).coerceIn(0f, 1f - side)
        return RectF(l, t, l + side, t + side)
    }

    private fun onDetections(list: List<Det>) {
        if (st == St.SCANNING) {
            for ((i, d) in list.withIndex()) {
                val b = d.box
                val cx = (b.left + b.right) / 2 - .5f
                val cy = (b.top + b.bottom) / 2 - .5f
                val area = (b.width() * b.height()).coerceIn(0f, .6f)
                if (area < .02f) continue
                val sc = area * (1f - 1.2f * (cx * cx + cy * cy))
                val key = if (d.id >= 0) d.id else -(i + 2)
                val c = cands[key]
                if (c == null) cands[key] = Cand(RectF(b), d.label, sc, 1, d.id)
                else { c.box = RectF(b); c.score += sc; c.n++; if (d.label != "Motivo") c.label = d.label }
            }
        } else if (st == St.FRAMING && trackId >= 0) {
            val d = list.firstOrNull { it.id == trackId } ?: return
            val f = frame ?: return
            val nb = boxFor(d.box)
            frame = RectF(
                f.left + (nb.left - f.left) * .35f, f.top + (nb.top - f.top) * .35f,
                f.right + (nb.right - f.right) * .35f, f.bottom + (nb.bottom - f.bottom) * .35f
            )
            reTpl = true
        }
    }

    private fun pickBest(): Cand? {
        var best: Cand? = null
        for (c in cands.values) {
            if (c.n < 2) continue
            if (best == null || c.score > best.score) best = c
        }
        return best
    }

    private fun labelScene(bmp: Bitmap, r: RectF) {
        val lb = labeler ?: return
        try {
            val x = (r.left * bmp.width).toInt().coerceIn(0, bmp.width - 2)
            val y = (r.top * bmp.height).toInt().coerceIn(0, bmp.height - 2)
            val w = (r.width() * bmp.width).toInt().coerceIn(2, bmp.width - x)
            val hh = (r.height() * bmp.height).toInt().coerceIn(2, bmp.height - y)
            val crop = Film.scaled(Bitmap.createBitmap(bmp, x, y, w, hh), 320)
            lb.process(InputImage.fromBitmap(crop, 0)).addOnSuccessListener { list ->
                val top = list.firstOrNull { it.confidence > .55f && ptLabels.containsKey(it.text) }
                if (top != null && st == St.FRAMING) subject = ptLabels[top.text] ?: subject
            }.addOnFailureListener { }
        } catch (e: Exception) { }
    }

    private fun onFrame(l: FloatArray, s: FloatArray, bmp: Bitmap) {
        lastBmp = bmp
        val now = System.currentTimeMillis()
        if (st == St.SCANNING) {
            guide.accumulate(l, s)
            val left = 3000L - (now - scanStart)
            ov.count = ceil(left / 1000.0).toInt().coerceIn(0, 3)
            if (left <= 0L) {
                val best = pickBest()
                val r: RectF?
                if (best != null) {
                    r = boxFor(best.box)
                    trackId = best.id
                    subject = best.label
                } else {
                    r = guide.pick(.38f)
                    trackId = -1
                    subject = "Motivo"
                }
                if (r == null) { cancelScan(); return }
                frame = r
                boxSide = r.width()
                guide.setTpl(l, r)
                st = St.FRAMING
                ov.count = 0
                refreshIcons()
                autoZoom()
                labelScene(bmp, r)
            }
        } else if (st == St.FRAMING) {
            if (now < zoomBusy) return
            val f = frame
            if (f != null && guide.tpl != null) {
                if (reTpl) { guide.setTpl(l, f); reTpl = false }
                else {
                    val nf = guide.track(l, f)
                    if (abs(nf.left - f.left) > .008f || abs(nf.top - f.top) > .008f) frame = nf
                }
            }
            evaluate(l)
        }
        ov.frame = frame
        ov.invalidate()
    }

    private fun autoZoom() {
        val c = cam ?: return
        val zs = c.cameraInfo.zoomState.value ?: return
        val f = frame ?: return
        val target = (zoomNow * (.6f / max(.05f, f.width()))).coerceIn(zs.minZoomRatio, min(zs.maxZoomRatio, 8f))
        val t = (target * 10).roundToInt() / 10f
        if (t / zoomNow < 1.12f) return
        applyZoom(t)
        autoZoomed = true
    }

    private fun applyZoom(target: Float) {
        val c = cam ?: return
        val k = target / zoomNow
        c.cameraControl.setZoomRatio(target)
        zoomNow = target
        updateZoomChips()
        if (st == St.FRAMING && frame != null) {
            zoomBusy = System.currentTimeMillis() + 800
            ui.postDelayed({
                val f = frame
                if (f != null) {
                    val nf = RectF(.5f + (f.left - .5f) * k, .5f + (f.top - .5f) * k, .5f + (f.right - .5f) * k, .5f + (f.bottom - .5f) * k)
                    frame = nf
                    pv.bitmap?.let { val (l, _) = guide.lum(it); guide.setTpl(l, nf) }
                }
            }, 500)
        }
    }

    private fun updateZoomChips() {
        val c = cam ?: return
        val zs = c.cameraInfo.zoomState.value ?: return
        zoomRow.removeAllViews()
        val list = ArrayList<Float>()
        for (q in listOf(.5f, 1f, 2f, 5f)) if (q >= zs.minZoomRatio - .01f && q <= zs.maxZoomRatio) list.add(q)
        val cur1 = (zoomNow * 10).roundToInt() / 10f
        if (list.none { abs(it - cur1) < .05f }) list.add(cur1)
        list.sort()
        for (q in list) {
            val lab = if (q == q.toInt().toFloat()) q.toInt().toString() else q.toString()
            val b = btn("$lab×") { applyZoom(q) }
            styleChip(b, abs(q - cur1) < .05f)
            val lp = LinearLayout.LayoutParams(-2, dp(34))
            lp.marginEnd = dp(8)
            zoomRow.addView(b, lp)
        }
    }

    private fun focus(x: Float, y: Float) {
        val c = cam ?: return
        try {
            val pt = pv.meteringPointFactory.createPoint(x * pv.width, y * pv.height)
            c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
        } catch (e: Exception) { }
    }

    private fun startCam() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val prov = f.get()
            if (manualMode) {
                bindCam(prov, CameraSelector.DEFAULT_BACK_CAMERA, true)
                return@addListener
            }
            val ef = ExtensionsManager.getInstanceAsync(this, prov)
            ef.addListener({
                var sel = CameraSelector.DEFAULT_BACK_CAMERA
                var ext = false
                try {
                    val em = ef.get()
                    for (mode in listOf(ExtensionMode.AUTO, ExtensionMode.HDR)) {
                        if (em.isExtensionAvailable(CameraSelector.DEFAULT_BACK_CAMERA, mode)) {
                            sel = em.getExtensionEnabledCameraSelector(CameraSelector.DEFAULT_BACK_CAMERA, mode)
                            ext = true
                            break
                        }
                    }
                } catch (e: Exception) { }
                if (!bindCam(prov, sel, !ext)) bindCam(prov, CameraSelector.DEFAULT_BACK_CAMERA, true)
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCam(prov: ProcessCameraProvider, sel: CameraSelector, interop: Boolean): Boolean {
        return try {
            val pbd = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3)
            if (interop) {
                Camera2Interop.Extender<Preview>(pbd).setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                        result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
                        result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastEt = it }
                    }
                })
            }
            val prev = pbd.build()
            prev.setSurfaceProvider(pv.surfaceProvider)
            capture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            prov.unbindAll()
            cam = prov.bindToLifecycle(this, sel, prev, capture)
            zoomNow = 1f
            setupControls()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun setupControls() {
        val c = cam ?: return
        pro.removeAllViews()
        updateZoomChips()
        val es = c.cameraInfo.exposureState
        if (es.isExposureCompensationSupported) {
            val r = es.exposureCompensationRange
            val step = es.exposureCompensationStep.toFloat()
            pro.addView(slider("Exposição", r.upper - r.lower, -r.lower, { String.format("%.1f", (it + r.lower) * step) }, null) {
                c.cameraControl.setExposureCompensationIndex(it + r.lower)
            })
        }
        try {
            val ci = Camera2CameraInfo.from(c.cameraInfo)
            val ir = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
            val er = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            if (ir != null && er != null) {
                val isoMin = max(ir.lower, 50)
                val isoMax = min(ir.upper, 3200)
                val etMin = max(er.lower, 125000L)
                val etMax = min(er.upper, 500000000L)
                var curIso = if (lastIso > 0) lastIso.coerceIn(isoMin, isoMax) else 100.coerceIn(isoMin, isoMax)
                var curEt = if (lastEt > 0) lastEt.coerceIn(etMin, etMax) else 10000000L.coerceIn(etMin, etMax)
                fun manual() {
                    Camera2CameraControl.from(c.cameraControl).setCaptureRequestOptions(
                        CaptureRequestOptions.Builder()
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                            .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, curIso)
                            .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, curEt)
                            .build()
                    )
                }
                val li = ln(isoMin.toDouble())
                val ri = ln(isoMax.toDouble())
                val le = ln(etMin.toDouble())
                val re = ln(etMax.toDouble())
                val p0 = (100 * (ln(curIso.toDouble()) - li) / (ri - li)).roundToInt()
                val p1 = (100 * (ln(curEt.toDouble()) - le) / (re - le)).roundToInt()
                pro.addView(slider("ISO", 100, p0, { exp(li + it / 100.0 * (ri - li)).roundToInt().toString() }, null) {
                    curIso = exp(li + it / 100.0 * (ri - li)).roundToInt().coerceIn(isoMin, isoMax); manual()
                })
                pro.addView(slider("Obturador", 100, p1, { "1/" + (1e9 / exp(le + it / 100.0 * (re - le))).roundToInt() }, null) {
                    curEt = exp(le + it / 100.0 * (re - le)).toLong().coerceIn(etMin, etMax); manual()
                })
                pro.addView(btn("Automático") {
                    Camera2CameraControl.from(c.cameraControl).clearCaptureRequestOptions()
                    setupControls()
                })
            }
        } catch (e: Exception) { }
    }

    private fun cropRatio(b: Bitmap, r: Float): Bitmap {
        val w = b.width
        val hh = b.height
        return if (w / hh.toFloat() > r) {
            val nw = (hh * r).toInt()
            Bitmap.createBitmap(b, (w - nw) / 2, 0, nw, hh)
        } else {
            val nh = (w / r).toInt()
            Bitmap.createBitmap(b, 0, (hh - nh) / 2, w, nh)
        }
    }

    private fun shoot() {
        val box = if (st == St.FRAMING && ready) frame?.let { RectF(it) } else null
        shBtn.isEnabled = false
        flash()
        shBtn.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        capture.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    origBytes = null
                    var iso = 0
                    var et = 0L
                    var bmp: Bitmap? = null
                    try {
                        val buf = image.planes[0].buffer
                        val bytes = ByteArray(buf.remaining())
                        buf.get(bytes)
                        origBytes = if (ratio == 3f / 4f) bytes else null
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        try {
                            val ex = android.media.ExifInterface(java.io.ByteArrayInputStream(bytes))
                            iso = ex.getAttributeInt("PhotographicSensitivity", 0)
                            if (iso == 0) iso = ex.getAttributeInt("ISOSpeedRatings", 0)
                            et = (ex.getAttributeDouble("ExposureTime", 0.0) * 1e9).toLong()
                        } catch (e: Exception) { }
                    } catch (e: Exception) { }
                    if (bmp == null) bmp = image.toBitmap()
                    image.close()
                    var b2: Bitmap = bmp!!
                    if (rot != 0) {
                        val m = Matrix()
                        m.postRotate(rot.toFloat())
                        b2 = Bitmap.createBitmap(b2, 0, 0, b2.width, b2.height, m, true)
                    }
                    b2 = Film.scaled(cropRatio(b2, ratio), 4000)
                    cap = Cap(zoomNow, if (iso > 0) iso else lastIso, if (et > 0L) et else lastEt, Date(), Build.MANUFACTURER + " " + Build.MODEL)
                    cancelScan()
                    openEditor(b2, box, true)
                } catch (e: Exception) {
                    toast("Erro ao processar a fotografia: " + e.javaClass.simpleName)
                }
                shBtn.isEnabled = true
            }
            override fun onError(exception: ImageCaptureException) {
                toast("Não foi possível fotografar")
                shBtn.isEnabled = true
            }
        })
    }

    private fun importUri(uri: Uri) {
        try {
            val s = ImageDecoder.createSource(contentResolver, uri)
            val bm = ImageDecoder.decodeBitmap(s) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val mx = max(info.size.width, info.size.height)
                if (mx > 3200) dec.setTargetSampleSize(mx / 3200 + 1)
            }
            cap = Cap(date = Date(), model = Build.MANUFACTURER + " " + Build.MODEL)
            origBytes = null
            openEditor(bm, null, false)
        } catch (e: Exception) {
            toast("Não foi possível abrir a imagem")
        }
    }

    // ---------- editor ----------
    private val tabNames = listOf("IA", "Looks", "Luz", "Cor", "Detalhe", "Efeitos", "Molduras")
    private var aiBase: HashMap<String, Int>? = null
    private var aiAmt = 100
    private var aiLookAmt = 80
    private var aiText = ""
    private var aiBusy = false
    private var holding = false
    private var lastProcessed: Bitmap? = null
    private lateinit var titleTv: TextView

    private fun lpw(w: Int, h: Int, endMargin: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(w, h)
        lp.marginEnd = endMargin
        return lp
    }

    private fun buildEd() {
        edScr = LinearLayout(this)
        edScr.orientation = LinearLayout.VERTICAL
        edScr.setBackgroundColor(Color.parseColor("#0A0A0A"))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(14), dp(10), dp(14), dp(4))
        top.addView(btn("‹") { show(0) }, lpw(dp(48), dp(40)))
        titleTv = tv("Editar", 15f)
        titleTv.gravity = Gravity.CENTER
        titleTv.typeface = medium()
        top.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        val sv = btn("Guardar") { save() }
        sv.background = pill(amber, amber)
        sv.setTextColor(Color.BLACK)
        top.addView(sv, lpw(-2, dp(40)))
        edScr.addView(top, LinearLayout.LayoutParams(-1, -2))

        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setPadding(dp(14), dp(8), dp(14), dp(8))
        iv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> showOriginal(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> showOriginal(false)
            }
            true
        }
        edScr.addView(iv, LinearLayout.LayoutParams(-1, 0, 1f))

        val tools = LinearLayout(this)
        tools.gravity = Gravity.CENTER
        undoBtn = btn("↶") { undo() }
        redoBtn = btn("↷") { redo() }
        cropBtn = btn("Recorte da moldura: sim") {
            cropOn = !cropOn
            rebuildBase()
            updateCropBtn()
            showTab(tabN)
            redraw()
        }
        tools.addView(undoBtn, lpw(dp(48), dp(34), dp(8)))
        tools.addView(cropBtn, lpw(-2, dp(34), dp(8)))
        tools.addView(redoBtn, lpw(dp(48), dp(34)))
        edScr.addView(tools, LinearLayout.LayoutParams(-1, -2))

        tabsRow = LinearLayout(this)
        tabNames.forEachIndexed { i, n ->
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val t = tv(n, 14f)
            t.typeface = medium()
            t.setPadding(dp(14), dp(10), dp(14), dp(6))
            col.addView(t)
            col.addView(View(this), LinearLayout.LayoutParams(dp(22), dp(2)))
            col.setOnClickListener { haptic(col); showTab(i) }
            tabsRow.addView(col)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(tabsRow)
        edScr.addView(hs, LinearLayout.LayoutParams(-1, -2))

        ctl = ScrollView(this)
        edScr.addView(ctl, LinearLayout.LayoutParams(-1, dp(196)))
        root.addView(edScr, FrameLayout.LayoutParams(-1, -1))

        flyView = ImageView(this)
        flyView.scaleType = ImageView.ScaleType.FIT_XY
        flyView.visibility = View.GONE
        flyView.outlineProvider = roundOutline(dp(22))
        flyView.clipToOutline = true
        root.addView(flyView, FrameLayout.LayoutParams(1, 1))
        flashView = View(this)
        flashView.setBackgroundColor(Color.WHITE)
        flashView.alpha = 0f
        root.addView(flashView, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showOriginal(on: Boolean) {
        holding = on
        if (on) {
            pb?.let { iv.setImageBitmap(it) }
            titleTv.text = "Original"
        } else {
            lastProcessed?.let { iv.setImageBitmap(it) }
            titleTv.text = "Editar"
        }
    }

    private fun updateCropBtn() {
        cropBtn.visibility = if (cropBox != null) View.VISIBLE else View.GONE
        cropBtn.text = if (cropOn) "Recorte da moldura: sim" else "Recorte da moldura: não"
    }

    private fun pushHist() {
        while (hist.size > hpos + 1) hist.removeAt(hist.size - 1)
        hist.add(cur.copy())
        hpos = hist.size - 1
        undoBtn.alpha = if (hpos > 0) 1f else .4f
        redoBtn.alpha = .4f
    }

    private fun undo() {
        if (hpos <= 0) return
        hpos--
        restoreHist()
    }

    private fun redo() {
        if (hpos >= hist.size - 1) return
        hpos++
        restoreHist()
    }

    private fun restoreHist() {
        cur = hist[hpos].copy()
        undoBtn.alpha = if (hpos > 0) 1f else .4f
        redoBtn.alpha = if (hpos < hist.size - 1) 1f else .4f
        showTab(tabN)
        redraw()
    }

    private fun curSrc(): Bitmap {
        val s = fullBmp ?: throw IllegalStateException("sem imagem")
        val b = cropBox
        if (!cropOn || b == null) return s
        val side = min(1f, b.width() * 1.24f)
        val cx = (b.left + b.right) / 2
        val cy = (b.top + b.bottom) / 2
        val l = (cx - side / 2).coerceIn(0f, 1f - side)
        val t = (cy - side / 2).coerceIn(0f, 1f - side)
        val x = (l * s.width).toInt().coerceIn(0, s.width - 2)
        val y = (t * s.height).toInt().coerceIn(0, s.height - 2)
        val w = (side * s.width).toInt().coerceIn(2, s.width - x)
        val hh = (side * s.height).toInt().coerceIn(2, s.height - y)
        return Bitmap.createBitmap(s, x, y, w, hh)
    }

    private fun rebuildBase() {
        val s = curSrc()
        pb = Film.scaled(s, 800)
        tb = Film.scaled(s, 110)
    }

    private fun openEditor(b: Bitmap, box: RectF?, anim: Boolean) {
        fullBmp = b
        cropBox = box
        cropOn = box != null
        seed = Random.nextInt(1, Int.MAX_VALUE)
        aiBase = null
        aiAmt = 100
        aiText = ""
        cur = P(look = LOOKS[0])
        hist.clear()
        hpos = -1
        rebuildBase()
        updateCropBtn()
        pushHist()
        showTab(0)
        if (anim) runFly(b) else { show(1); redraw() }
    }

    /** A foto "encolhe" do ecrã da câmara para o sítio onde fica no editor. */
    private fun runFly(b: Bitmap) {
        val a = IntArray(2)
        pv.getLocationInWindow(a)
        val r0 = IntArray(2)
        root.getLocationInWindow(r0)
        val sx = a[0] - r0[0]
        val sy = a[1] - r0[1]
        val sw = pv.width
        val sh = pv.height
        edScr.alpha = 0f
        edScr.visibility = View.VISIBLE
        flyView.setImageBitmap(b)
        val lp = FrameLayout.LayoutParams(sw, sh, Gravity.TOP or Gravity.START)
        lp.leftMargin = sx
        lp.topMargin = sy
        flyView.layoutParams = lp
        flyView.pivotX = 0f
        flyView.pivotY = 0f
        flyView.translationX = 0f
        flyView.translationY = 0f
        flyView.scaleX = 1f
        flyView.scaleY = 1f
        flyView.alpha = 1f
        flyView.visibility = View.VISIBLE
        redraw()
        edScr.post {
            val c = IntArray(2)
            iv.getLocationInWindow(c)
            val ex = c[0] - r0[0]
            val ey = c[1] - r0[1]
            val cw = (iv.width - iv.paddingLeft - iv.paddingRight).toFloat()
            val ch = (iv.height - iv.paddingTop - iv.paddingBottom).toFloat()
            val ar = b.width.toFloat() / b.height
            var tw = cw
            var th = tw / ar
            if (th > ch) { th = ch; tw = th * ar }
            val tx = ex + iv.paddingLeft + (cw - tw) / 2
            val ty = ey + iv.paddingTop + (ch - th) / 2
            val k = tw / sw
            flyView.animate().translationX(tx - sx).translationY(ty - sy).scaleX(k).scaleY(k)
                .setDuration(460).setInterpolator(DecelerateInterpolator(2f))
                .withEndAction { endFly() }.start()
            camScr.animate().alpha(0f).setDuration(320).start()
            edScr.animate().alpha(1f).setStartDelay(160).setDuration(320).start()
        }
    }

    private fun endFly() {
        flyView.visibility = View.GONE
        camScr.visibility = View.GONE
        camScr.alpha = 1f
        edScr.alpha = 1f
        edScr.animate().setStartDelay(0)
    }

    // ---------- IA ----------
    private fun runAI() {
        if (aiBusy) return
        val base = pb ?: return
        aiBusy = true
        aiText = "A analisar a luz, a cor e o tipo de cena…"
        showTab(0)
        val lb = labeler
        val small = Film.scaled(base, 320)
        worker.execute {
            try {
                val stt = AutoEdit.stats(small)
                ui.post {
                    if (lb == null) finishAI(stt, emptyList())
                    else lb.process(InputImage.fromBitmap(small, 0))
                        .addOnSuccessListener { list -> finishAI(stt, list.filter { it.confidence > .5f }.map { it.text }) }
                        .addOnFailureListener { finishAI(stt, emptyList()) }
                }
            } catch (e: Exception) {
                ui.post { aiBusy = false; aiText = "Não foi possível analisar a fotografia."; showTab(0) }
            }
        }
    }

    private fun finishAI(stt: AutoEdit.Stats, labels: List<String>) {
        val r = AutoEdit.build(stt, labels)
        aiBase = HashMap(r.params)
        aiAmt = 100
        aiLookAmt = 80
        val lo = LOOKS.firstOrNull { it.name == r.look } ?: LOOKS[0]
        cur = P(HashMap(r.params), lo, aiLookAmt, cur.frame, cur.date)
        aiText = r.text
        aiBusy = false
        pushHist()
        showTab(0)
        redraw()
    }

    private fun applyAI() {
        val base = aiBase ?: return
        cur.a.clear()
        for ((k, v) in base) cur.a[k] = v * aiAmt / 100
        cur.amt = aiLookAmt * aiAmt / 100
    }

    // ---------- separadores ----------
    private fun sliderRows(box: LinearLayout, items: List<Triple<String, String, Boolean>>) {
        for ((k, lab, signed) in items) {
            val off = if (signed) 100 else 0
            box.addView(slider(lab, if (signed) 200 else 100, cur.u(k) + off, { (it - off).toString() }, { pushHist() }, off) {
                cur.a[k] = it - off
                redraw()
            })
        }
    }

    private fun showTab(n: Int) {
        tabN = n
        for (i in 0 until tabsRow.childCount) {
            val col = tabsRow.getChildAt(i) as LinearLayout
            (col.getChildAt(0) as TextView).setTextColor(if (i == n) Color.WHITE else grey)
            col.getChildAt(1).setBackgroundColor(if (i == n) amber else Color.TRANSPARENT)
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(10))
        when (n) {
            0 -> {
                val b = btn("✦  Melhorar com IA") { runAI() }
                b.background = pill(amber, amber)
                b.setTextColor(Color.BLACK)
                b.textSize = 15f
                box.addView(b, LinearLayout.LayoutParams(-1, dp(48)))
                val msg = tv(
                    if (aiText.isEmpty()) "A IA analisa a luz, a cor e o tipo de cena e faz a melhor edição por ti. Depois podes ajustar o que quiseres." else aiText,
                    12.5f
                )
                msg.setTextColor(grey)
                msg.setPadding(dp(2), dp(10), dp(2), dp(6))
                box.addView(msg)
                if (aiBase != null) {
                    box.addView(slider("Intensidade", 100, aiAmt, { "$it%" }, { pushHist() }) {
                        aiAmt = it
                        applyAI()
                        redraw()
                    })
                }
            }
            1 -> {
                val hs = HorizontalScrollView(this)
                hs.isHorizontalScrollBarEnabled = false
                val row = LinearLayout(this)
                val thumb = tb
                for (lo in LOOKS) {
                    val col = LinearLayout(this)
                    col.orientation = LinearLayout.VERTICAL
                    col.gravity = Gravity.CENTER
                    col.setPadding(dp(4), dp(4), dp(4), dp(4))
                    if (cur.look === lo) col.background = pill(Color.TRANSPARENT, amber)
                    val im = ImageView(this)
                    im.scaleType = ImageView.ScaleType.CENTER_CROP
                    im.outlineProvider = roundOutline(dp(10))
                    im.clipToOutline = true
                    if (thumb != null) im.setImageBitmap(Film.render(thumb, P(look = lo), seed))
                    col.addView(im, LinearLayout.LayoutParams(dp(70), dp(92)))
                    col.addView(tv(lo.name, 12f))
                    col.setOnClickListener { haptic(col); cur.look = lo; cur.amt = 100; pushHist(); showTab(1); redraw() }
                    row.addView(col, lpw(-2, -2, dp(6)))
                }
                hs.addView(row)
                box.addView(hs)
                if (cur.look != null && cur.look?.name != "Original") {
                    box.addView(slider("Intensidade", 100, cur.amt, { "$it%" }, { pushHist() }) {
                        cur.amt = it
                        redraw()
                    })
                }
            }
            2 -> sliderRows(box, listOf(
                Triple("exposure", "Exposição", true), Triple("contrast", "Contraste", true),
                Triple("highlights", "Realces", true), Triple("shadows", "Sombras", true),
                Triple("whites", "Brancos", true), Triple("blacks", "Pretos", true)
            ))
            3 -> sliderRows(box, listOf(
                Triple("temp", "Temperatura", true), Triple("tint", "Tonalidade", true),
                Triple("vibrance", "Vibração", true), Triple("sat", "Saturação", true)
            ))
            4 -> sliderRows(box, listOf(
                Triple("clarity", "Clareza", true), Triple("sharpen", "Nitidez", false), Triple("fade", "Desvanecer", false)
            ))
            5 -> sliderRows(box, listOf(
                Triple("grain", "Grão", false), Triple("halation", "Halation", false), Triple("glow", "Brilho suave", false),
                Triple("leak", "Fugas de luz", false), Triple("dust", "Pó e riscos", false), Triple("vig", "Vinheta", false)
            ))
            else -> {
                val hs = HorizontalScrollView(this)
                hs.isHorizontalScrollBarEnabled = false
                val row = LinearLayout(this)
                for ((k, lab) in FR) {
                    val b = btn(lab) { cur.frame = k; pushHist(); showTab(6); redraw() }
                    styleChip(b, cur.frame == k)
                    row.addView(b, lpw(-2, dp(36), dp(8)))
                }
                hs.addView(row)
                box.addView(hs)
                val db = btn(if (cur.date) "Carimbo de data: sim" else "Carimbo de data: não") {
                    cur.date = !cur.date; pushHist(); showTab(6); redraw()
                }
                styleChip(db, cur.date)
                val dl = LinearLayout.LayoutParams(-2, dp(36))
                dl.topMargin = dp(14)
                box.addView(db, dl)
            }
        }
        ctl.removeAllViews()
        ctl.addView(box)
    }

    private fun redraw() {
        val base = pb ?: return
        val v = ++ver
        val pc = cur.copy()
        val cp = cap
        val sd = seed
        worker.execute {
            try {
                if (v != ver) return@execute
                val o = Film.compose(Film.render(base, pc, sd), pc, cp)
                runOnUiThread {
                    if (v == ver) {
                        lastProcessed = o
                        if (!holding) iv.setImageBitmap(o)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Erro na revelação: " + e.javaClass.simpleName) }
            }
        }
    }

    private fun isIdentity(p: P): Boolean =
        p.a.values.all { it == 0 } && (p.look == null || p.look?.name == "Original" || p.amt == 0) && p.frame == "plain" && !p.date

    private fun save() {
        val s = try { curSrc() } catch (e: Exception) { return }
        val pc = cur.copy()
        val cp = cap
        val sd = seed
        val raw = origBytes
        val direct = raw != null && !(cropOn && cropBox != null) && isIdentity(pc)
        toast("A guardar…")
        worker.execute {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_" + stamp + ".jpg")
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                cv.put(MediaStore.Images.Media.DATE_TAKEN, cp.date.time)
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Camera")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                val th: Bitmap
                if (direct && raw != null) {
                    contentResolver.openOutputStream(uri)!!.use { it.write(raw) }
                    th = Film.scaled(s, 160)
                } else {
                    val o = Film.compose(Film.render(Film.scaled(s, 4000), pc, sd), pc, cp)
                    contentResolver.openOutputStream(uri)!!.use { o.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                    th = Film.scaled(o, 160)
                }
                runOnUiThread {
                    galThumb.setImageBitmap(th)
                    toast("Guardada na galeria")
                    show(0)
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Não foi possível guardar") }
            }
        }
    }
}
